#!/usr/bin/env bash
# Сборка мода Dirronlive Bridge, проверки карты в настоящем Minecraft и
# сборка готового мира DirronParkour. Запускается на GitHub из папки
# dirronlive/dirronlive_bridge. Итог — build/installer/*.zip и *.jar.
set -u
chmod +x gradlew
status=0
mkdir -p build/installer

note() { echo "::notice title=$1::$2"; }
err() { echo "::error title=$1::$2"; }

# 1. Сборка и обычные тесты (протокол, генератор 100 комнат).
./gradlew build --stacktrace --no-daemon 2>&1 | tee build.log
if [ "${PIPESTATUS[0]}" -ne 0 ]; then
  grep -E "error:|FAILED|BUILD FAILED|What went wrong" -A3 build.log | head -60 | while IFS= read -r line; do
    err "mod build" "$line"
  done
  exit 1
fi
grep -E " (PASSED|FAILED|SKIPPED)$|tests completed" build.log | while IFS= read -r line; do
  note "mod test" "$line"
done

jar=$(ls build/libs/DirronliveBridge-*.jar | grep -v -- '-sources' | head -1)
nested=$(unzip -l "$jar" | grep -c "META-INF/jars/")
note "mod jar" "$(basename "$jar"): $(stat -c%s "$jar") bytes, вложенных модулей Fabric API: ${nested}"
unzip -l "$jar" | grep -q "fabric.mod.json" || { err "mod jar" "нет fabric.mod.json"; exit 1; }
[ "$nested" -ge 3 ] || { err "mod jar" "модули Fabric API не упакованы внутрь"; exit 1; }
if unzip -l "$jar" | grep -q "META-INF/jars/fabric-gametest"; then
  err "mod jar" "в jar попал модуль gametest"; status=1
fi
cp "$jar" build/installer/

# 2. Проверки карты внутри Minecraft 1.21.1 (сервер GameTest).
./gradlew runGametest --no-daemon 2>&1 | tee gametest.log
checks=$(grep -c "PARKOUR_CHECK" gametest.log || true)
grep "PARKOUR_CHECK ok" gametest.log | sed 's/.*PARKOUR_CHECK ok | //' | while IFS= read -r line; do
  note "в игре: OK" "$line"
done
grep "PARKOUR_CHECK fail" gametest.log | sed 's/.*PARKOUR_CHECK fail | //' | while IFS= read -r line; do
  err "в игре: ОШИБКА" "$line"
done
if grep -q "PARKOUR_CHECK fail" gametest.log; then status=1; fi
if [ "$checks" -eq 0 ]; then
  err "в игре" "проверки GameTest не запустились"
  grep -E "Exception|Error|FAILED|failed" gametest.log | head -30 | while IFS= read -r line; do err "gametest log" "$line"; done
  status=1
fi
if [ -f build/gametest/report.xml ]; then
  python3 - <<'PY'
import xml.etree.ElementTree as ET
root = ET.parse('build/gametest/report.xml').getroot()
cases = root.iter('testcase')
total = failed = 0
for c in cases:
    total += 1
    f = c.find('failure')
    if f is not None:
        failed += 1
        print(f"::error title=GameTest {c.get('name')}::{(f.get('message') or '')[:500]}")
print(f"::notice title=GameTest::{total - failed} из {total} проверок прошли")
PY
fi

# 3. Готовый мир DirronParkour (выделенный сервер строит карту и выключается).
./gradlew worldZip --no-daemon 2>&1 | tee world.log
if grep -q "DIRRON_WORLD_BUILT" world.log && [ -f build/installer/DirronParkour-world.zip ]; then
  note "мир" "$(grep -o 'DIRRON_WORLD_BUILT.*' world.log | head -1), архив $(stat -c%s build/installer/DirronParkour-world.zip) bytes"
  unzip -l build/installer/DirronParkour-world.zip | grep -q "DirronParkour/level.dat" || { err "мир" "нет level.dat"; status=1; }
  unzip -l build/installer/DirronParkour-world.zip | grep -q "DirronParkour/region/" || { err "мир" "нет region"; status=1; }
else
  err "мир" "мир не построен"
  grep -E "Exception|Error|FAILED" world.log | head -30 | while IFS= read -r line; do err "world log" "$line"; done
  status=1
fi

# 4. Набор «всё в одном»: мод + мир + инструкция.
if [ -f build/installer/DirronParkour-world.zip ]; then
  rm -rf build/kit && mkdir -p build/kit/mods build/kit/saves
  cp "$jar" build/kit/mods/
  (cd build/kit/saves && unzip -q ../../installer/DirronParkour-world.zip)
  cp ../tools/parkour-kit-readme.txt "build/kit/Как установить.txt"
  (cd build/kit && zip -q -r ../installer/DirronParkour-kit.zip .)
  note "набор" "DirronParkour-kit.zip: $(stat -c%s build/installer/DirronParkour-kit.zip) bytes"
fi

ls -la build/installer
exit $status
