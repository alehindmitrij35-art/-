package dev.dirronlive.parkour.map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

/** Все 100 комнат: проходимость, точки для действий, оформление. */
class MapGeneratorTest {
    static final int BX = 0, BY = 100, BZ = 0;

    static RoomPlan room(int n) {
        return ParkourLayout.plan(BX, BY, BZ, n);
    }

    /** Можно ли допрыгнуть с a на b по правилам ванильного Minecraft. */
    static boolean canJump(Platform a, Platform b) {
        double gap = a.airGapTo(b);
        int dy = b.y() - a.y();
        if (a.kind() == Platform.Kind.BOUNCE) return dy <= 2 && gap <= 3.2;
        if (dy > 1) return false;
        if (dy == 1) return gap <= 2.25;
        if (dy >= -6) return gap <= 3.2;
        return false;
    }

    static boolean finishReachable(RoomPlan plan) {
        List<Platform> ps = plan.platforms;
        Set<Integer> seen = new HashSet<>();
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        queue.add(0);
        seen.add(0);
        while (!queue.isEmpty()) {
            Platform a = ps.get(queue.poll());
            if (a.kind() == Platform.Kind.FINISH) return true;
            for (Platform b : ps) {
                if (!seen.contains(b.index()) && canJump(a, b)) {
                    seen.add(b.index());
                    queue.add(b.index());
                }
            }
        }
        return false;
    }

    @Test
    void allRoomsAreCompletable() {
        for (int n = 1; n <= 100; n++) {
            RoomPlan plan = room(n);
            assertTrue(finishReachable(plan), "комната " + n + ": финиш недостижим честными прыжками");
            assertEquals(Platform.Kind.START, plan.start().kind(), "комната " + n);
            assertEquals(Platform.Kind.FINISH, plan.finish().kind(), "комната " + n);
            assertTrue(plan.platforms.size() >= 8, "комната " + n + ": слишком короткая");
            assertEquals(Platform.Kind.FIRST, plan.platforms.get(1).kind(), "комната " + n + ": заметная первая платформа");
        }
    }

    @Test
    void headroomAbovePlatforms() {
        for (int n = 1; n <= 100; n++) {
            RoomPlan plan = room(n);
            for (Platform p : plan.platforms) {
                for (int x = p.x0(); x <= p.x1(); x++) {
                    for (int z = p.z0(); z <= p.z1(); z++) {
                        for (int dy = 1; dy <= 2; dy++) {
                            String above = plan.blueprint.get(x, p.y() + dy, z);
                            assertTrue(above == null || above.contains("chain"),
                                    "комната " + n + ": над платформой " + p.index() + " блок " + above);
                        }
                    }
                }
            }
        }
    }

    @Test
    void actionPointsExistInEveryRoom() {
        for (int n = 1; n <= 100; n++) {
            RoomPlan plan = room(n);
            assertFalse(plan.bridge.isEmpty(), "комната " + n + ": нет разрыва для «Моста зрителя»");
            assertTrue(plan.shortcut.size() >= 3, "комната " + n + ": нет «Секретной срезки»");
            assertTrue(plan.vanishCandidates.size() >= 4, "комната " + n + ": мало ступеней для «Исчезающей ступени»");
            assertFalse(plan.vanishCandidates.contains(0), "старт не исчезает");
            assertFalse(plan.vanishCandidates.contains(plan.finish().index()), "финиш не исчезает");
            for (int[] b : plan.bridge) {
                assertFalse(plan.blueprint.has(b[0], b[1], b[2]), "мост ставится только в пустоту");
            }
            for (int[] s : plan.shortcut) {
                assertFalse(plan.blueprint.has(s[0], s[1], s[2]), "срезка ставится только в пустоту");
            }
        }
    }

    @Test
    void roomsDoNotOverlapAndHaveThemes() {
        for (int n = 1; n <= 100; n++) {
            RoomPlan plan = room(n);
            assertTrue(plan.maxX - plan.minX < ParkourLayout.SPACING - 4, "комната " + n + " шире ячейки");
            assertTrue(plan.maxZ - plan.minZ < ParkourLayout.SPACING - 4, "комната " + n + " глубже ячейки");
            assertEquals(Theme.values()[(n - 1) / 10], plan.theme);
            assertTrue(plan.fallY < plan.start().y(), "порог падения ниже старта");
        }
    }

    @Test
    void spawnFacesFirstJumpAndNumberIsVisible() {
        for (int n = 1; n <= 100; n++) {
            RoomPlan plan = room(n);
            Platform first = plan.platforms.get(1);
            double yaw = Math.toRadians(plan.spawnYaw);
            double lookX = -Math.sin(yaw), lookZ = Math.cos(yaw);
            double toX = first.centerX() - plan.spawnX, toZ = first.centerZ() - plan.spawnZ;
            double cos = (lookX * toX + lookZ * toZ) / Math.hypot(toX, toZ);
            assertTrue(cos > 0.9, "комната " + n + ": взгляд не на первый прыжок");
            int numberBlocks = 0;
            int x = ParkourLayout.originX(BX, n) + RoomGenerator.NUMBER_X;
            for (long key : plan.blueprint.blocks().keySet()) {
                if (Blueprint.keyX(key) == x && Blueprint.keyY(key) >= BY + 7) numberBlocks++;
            }
            assertTrue(numberBlocks >= 20, "комната " + n + ": нет крупного номера");
        }
    }

    @Test
    void finaleRoomHasLetterAndEyes() {
        RoomPlan plan = room(100);
        assertEquals(18, plan.eyes.size(), "два глаза 3×3");
        assertTrue(plan.finish().y() >= BY + 30, "финиш на вершине буквы");
        int letter = 0;
        for (String block : plan.blueprint.blocks().values()) {
            if (block.equals("minecraft:purple_concrete")) letter++;
        }
        assertTrue(letter > 200, "огромная буква D");
    }

    @Test
    void deterministic() {
        assertEquals(room(37).blueprint.blocks(), room(37).blueprint.blocks());
    }

    @Test
    void blueprintKeyRoundTrip() {
        int[][] points = {{0, 0, 0}, {-5, 100, 7}, {1260, -40, -1300}, {33554431 >> 2, 2047, -(33554431 >> 2)}};
        for (int[] p : points) {
            long key = Blueprint.key(p[0], p[1], p[2]);
            assertEquals(p[0], Blueprint.keyX(key));
            assertEquals(p[1], Blueprint.keyY(key));
            assertEquals(p[2], Blueprint.keyZ(key));
        }
    }
}
