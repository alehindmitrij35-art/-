package dev.dirronlive.bridge;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Протокол обмена с программой Dirronlive (JSON по WebSocket).
 *
 * <pre>
 * Мод → программа:
 *   {"type":"hello","protocol":1,"modVersion":"1.0.0","minecraftVersion":"1.21.1","worldReady":false}
 *   {"type":"world","worldReady":true}
 *   {"type":"ack","id":"…"}
 *   {"type":"parkour","available":true,"room":12,"finished":false,"falls":3,"seconds":95}
 *   {"type":"actionResult","id":"…","ok":true,"result":"Комната 12 → 11","room":11}
 * Программа → мод:
 *   {"type":"welcome","app":"Dirronlive","protocol":1}
 *   {"type":"gift","id":"…","viewerName":"…","giftName":"Роза","count":1}
 *   {"type":"gift","id":"…","viewerName":"…","giftName":"Роза","count":1,"combo":true,"comboTotal":15}
 *   {"type":"action","id":"…","action":"room_back","params":{"rooms":1},
 *    "label":"Роза","viewerName":"Alex","test":false}
 *   {"type":"countdown","id":"…","title":"Комната назад через","seconds":10}
 *   {"type":"countdownCancel","id":"…","text":"Чат спас: «Комната назад» отменена"}
 * </pre>
 *
 * <p>{@code count} — сколько подарков применить сейчас (для шага комбо —
 * прирост), {@code comboTotal} — сколько всего в серии комбо.
 */
public final class BridgeProtocol {
    /** 2 — добавлены действия паркура; сообщения версии 1 понимаются как раньше. */
    public static final int VERSION = 2;
    public static final int DEFAULT_PORT = 8765;

    private BridgeProtocol() {}

    /**
     * Подарок, пришедший из программы. {@code comboTotal} = 0 для одиночного
     * подарка, иначе — сколько всего подарков в серии комбо.
     */
    public record Gift(String id, String viewerName, String giftName, int count, int comboTotal) {
        public boolean isCombo() {
            return comboTotal > 0;
        }

        /** Сколько подарков показать: для серии — итог серии. */
        public int total() {
            return isCombo() ? comboTotal : count;
        }

        /** «Роза» ×5 */
        public String giftText() {
            return "«" + giftName + "» ×" + total();
        }

        /** Текст над панелью быстрого доступа: «Dirronlive • Alex отправил «Роза» ×5». */
        public String overlayText() {
            return "Dirronlive • " + viewerName + " отправил " + giftText();
        }
    }

    public static String hello(String modVersion, String minecraftVersion, boolean worldReady) {
        return MiniJson.object(
                "type", "hello",
                "protocol", VERSION,
                "modVersion", modVersion,
                "minecraftVersion", minecraftVersion,
                "worldReady", worldReady,
                "parkourActions", true);
    }

    /** Действие за подарок (паркур). */
    public record Action(String id, String action, Map<String, Object> params, String label,
                         String viewerName, boolean test) {}

    /** Ответ мода на действие. {@code room} — комната игрока после действия (0 — неизвестно). */
    public record ActionResult(boolean ok, String result, int room) {}

    /** Состояние паркур-карты в открытом мире. */
    public record ParkourStatus(boolean available, int room, boolean finished, int falls, long seconds) {}

    /** Обратный отсчёт («Второй шанс от чата»). */
    public record Countdown(String id, String title, int seconds) {}

    public static String actionResult(String id, ActionResult r) {
        return MiniJson.object("type", "actionResult", "id", id, "ok", r.ok(), "result", r.result(), "room", r.room());
    }

    public static String parkour(ParkourStatus s) {
        return MiniJson.object("type", "parkour", "available", s.available(), "room", s.room(),
                "finished", s.finished(), "falls", s.falls(), "seconds", s.seconds());
    }

    public static String type(String text) {
        try {
            return MiniJson.parseObject(text).get("type") instanceof String t ? t : null;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** Действие или {@code null}, если сообщение другое или повреждено. */
    public static Action parseAction(String text) {
        Map<String, Object> m;
        try {
            m = MiniJson.parseObject(text);
        } catch (IllegalArgumentException e) {
            return null;
        }
        if (!"action".equals(m.get("type"))) return null;
        if (!(m.get("id") instanceof String id) || id.isBlank() || id.length() > 128) return null;
        if (!(m.get("action") instanceof String action) || !action.matches("[a-z_]{1,40}")) return null;
        Map<String, Object> params = new LinkedHashMap<>();
        if (m.get("params") instanceof Map<?, ?> raw) {
            raw.forEach((k, v) -> {
                if (k instanceof String key && (v instanceof Number || v instanceof String || v instanceof Boolean)) {
                    params.put(key, v);
                }
            });
        }
        return new Action(id, action, params, clean(m.get("label"), ""), clean(m.get("viewerName"), ""),
                Boolean.TRUE.equals(m.get("test")));
    }

    public static Countdown parseCountdown(String text) {
        Map<String, Object> m;
        try {
            m = MiniJson.parseObject(text);
        } catch (IllegalArgumentException e) {
            return null;
        }
        String type = String.valueOf(m.get("type"));
        if (!type.equals("countdown") && !type.equals("countdownCancel")) return null;
        if (!(m.get("id") instanceof String id) || id.isBlank()) return null;
        int seconds = m.get("seconds") instanceof Number n ? Math.max(0, Math.min(120, n.intValue())) : 0;
        String title = type.equals("countdown") ? cleanLong(m.get("title"), "Обратный отсчёт")
                : cleanLong(m.get("text"), "");
        return new Countdown(id, title, type.equals("countdown") ? Math.max(1, seconds) : 0);
    }

    static String cleanLong(Object value, String fallback) {
        if (!(value instanceof String s)) return fallback;
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length() && out.length() < 96; i++) {
            char c = s.charAt(i);
            if (c == '§' || Character.isISOControl(c)) continue;
            out.append(c);
        }
        String result = out.toString().strip();
        return result.isEmpty() ? fallback : result;
    }

    public static String world(boolean worldReady) {
        return MiniJson.object("type", "world", "worldReady", worldReady);
    }

    public static String ack(String id) {
        return MiniJson.object("type", "ack", "id", id);
    }

    /** Возвращает подарок или {@code null}, если сообщение не подарок или повреждено. */
    public static Gift parseGift(String text) {
        Map<String, Object> m;
        try {
            m = MiniJson.parseObject(text);
        } catch (IllegalArgumentException e) {
            return null;
        }
        if (!"gift".equals(m.get("type"))) return null;
        if (!(m.get("id") instanceof String id) || id.isBlank() || id.length() > 128) return null;
        int count = m.get("count") instanceof Long n && n >= 1 && n <= 1_000_000 ? n.intValue() : 1;
        int comboTotal = m.get("comboTotal") instanceof Long t && t >= 1 && t <= 1_000_000 ? t.intValue() : 0;
        if (comboTotal > 0 && comboTotal < count) comboTotal = count;
        return new Gift(
                id,
                clean(m.get("viewerName"), "Зритель"),
                clean(m.get("giftName"), "Подарок"),
                count,
                comboTotal);
    }

    /** Убирает управляющие символы и коды форматирования Minecraft (§), ограничивает длину. */
    static String clean(Object value, String fallback) {
        if (!(value instanceof String s)) return fallback;
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length() && out.length() < 48; i++) {
            char c = s.charAt(i);
            if (c == '§' || Character.isISOControl(c)) continue;
            out.append(c);
        }
        String result = out.toString().strip();
        return result.isEmpty() ? fallback : result;
    }
}
