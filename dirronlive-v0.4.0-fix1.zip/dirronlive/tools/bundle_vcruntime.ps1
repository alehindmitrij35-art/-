﻿# Copies the Visual C++ runtime next to dirronlive.exe so the program
# starts on a PC without "Microsoft Visual C++ Redistributable".
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$release = Join-Path $root 'build\windows\x64\runner\Release'
if (-not (Test-Path (Join-Path $release 'dirronlive.exe'))) {
    Write-Host "Release build not found: $release. Run: flutter build windows --release" -ForegroundColor Red
    exit 1
}
$system32 = Join-Path $env:WINDIR 'System32'
foreach ($dll in 'msvcp140.dll', 'vcruntime140.dll', 'vcruntime140_1.dll') {
    $src = Join-Path $system32 $dll
    if (Test-Path $src) {
        Copy-Item $src $release -Force
        Write-Host "Bundled $dll"
    } else {
        Write-Host "Not found, skipped: $src" -ForegroundColor Yellow
    }
}

# Коннектор TikTok LIVE (Node.js + tiktok-live-connector) рядом с программой.
& (Join-Path $PSScriptRoot 'bundle_tiktok.ps1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

# Заодно убеждаемся, что в exe правильный значок.
& (Join-Path $PSScriptRoot 'verify_exe_icon.ps1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
