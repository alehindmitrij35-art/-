// Поддельная tiktok-live-connector для тестов коннектора.
// Сценарий задаётся переменной DIRRONLIVE_FAKE_SCENARIO.
import { EventEmitter } from 'node:events';

export const VERSION = 'fake';
export const WebcastEvent = { GIFT: 'gift', STREAM_END: 'streamEnd' };
export const ControlEvent = { CONNECTED: 'connected', DISCONNECTED: 'disconnected', ERROR: 'error' };
export const SignConfig = { apiKey: undefined };
export class UserOfflineError extends Error { constructor(m) { super(m); this.name = 'UserOfflineError'; } }

const gift = (over) => ({
  common: { msgId: BigInt(over.msgId ?? 1), createTime: 1700000000000n },
  giftId: 5655,
  groupId: over.groupId ?? 0n,
  repeatCount: over.repeatCount ?? 1,
  repeatEnd: over.repeatEnd ?? false,
  giftDetails: { giftName: 'Rose', giftType: over.giftType ?? 1 },
  user: { userId: 42n, uniqueId: 'alex_fan', nickname: 'Alex' },
});

export class TikTokLiveConnection extends EventEmitter {
  constructor(uniqueId, options) {
    super();
    this.uniqueId = uniqueId;
    this.options = options;
  }

  async connect() {
    const scenario = process.env.DIRRONLIVE_FAKE_SCENARIO ?? 'gifts';
    if (scenario === 'offline') throw new UserOfflineError("The requested user isn't online :(");
    if (scenario === 'network') {
      const e = new Error('getaddrinfo ENOTFOUND www.tiktok.com');
      e.code = 'ENOTFOUND';
      throw e;
    }
    setTimeout(() => {
      if (scenario === 'gifts') {
        for (let n = 1; n <= 5; n++) {
          this.emit('gift', gift({ msgId: 100 + n, groupId: 777n, repeatCount: n, repeatEnd: false }));
        }
        this.emit('gift', gift({ msgId: 106, groupId: 777n, repeatCount: 5, repeatEnd: 1 }));
        this.emit('gift', gift({ msgId: 200, giftType: 2, repeatCount: 1, repeatEnd: false }));
      }
      if (scenario === 'gifts' || scenario === 'end') {
        this.emit('streamEnd', { action: 3 });
      }
      if (scenario === 'drop') {
        this.emit('disconnected', { code: 1006, reason: 'network lost' });
      }
    }, 20);
    return { roomId: 7300000000000000001n };
  }

  async fetchAvailableGifts() {
    const scenario = process.env.DIRRONLIVE_FAKE_SCENARIO ?? 'gifts';
    if (scenario === 'offline') throw new UserOfflineError("The requested user isn't online :(");
    return [
      { id: 5655, name: 'Rose', diamond_count: 1, image: { url_list: ['https://example.test/rose.png'] } },
      { id: 5487n, name: 'Finger Heart', diamond_count: 5 },
      { id: 5655, name: 'Rose', diamond_count: 1 },
      { id: 0, name: 'Broken' },
      { id: 6064, name: '' },
    ];
  }

  disconnect() {}
}
