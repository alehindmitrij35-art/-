// Экран «Режимы → Dirron Parkour: 100 комнат»: выбрать подарок, назначить
// действие, «Проверить в игре», сохранить правило, увидеть итог в истории.

import 'dart:async';

import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/minecraft/link_protocol.dart';
import 'package:dirronlive/features/minecraft/link_state.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:dirronlive/features/parkour/parkour_rules.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';
import 'support/test_app.dart';

/// Связь «как с модом 2.0 на карте», без сокетов: действия выполняются сразу.
class ParkourFakeLink extends FakeLinkController {
  ParkourFakeLink(super.initial);

  final StreamController<ModActionResult> _results = StreamController<ModActionResult>.broadcast();
  final List<Map<String, Object?>> sent = [];
  int room = 12;

  @override
  Stream<ModActionResult> get actionResults => _results.stream;

  @override
  bool sendAction({
    required String id,
    required String action,
    required Map<String, Object?> params,
    required String label,
    required String viewerName,
    required bool test,
  }) {
    sent.add({'id': id, 'action': action, 'params': params, 'test': test});
    final from = room;
    final rooms = (params['rooms'] as num?)?.toInt() ?? 1;
    if (action == 'room_back') room = (room - rooms).clamp(1, 100).toInt();
    if (action == 'goto_room') room = ((params['room'] as num?)?.toInt() ?? room).clamp(1, 100).toInt();
    scheduleMicrotask(() {
      _results.add(ModActionResult(id: id, ok: true, result: 'Комната $from → $room', room: room));
      state = state.copyWith(parkour: ParkourInfo(available: true, room: room));
    });
    return true;
  }

  @override
  bool sendCountdown(String id, String title, int seconds) => true;
}

const _ready = MinecraftLinkState(
  phase: LinkPhase.worldReady,
  port: 8765,
  modVersion: '2.0.0',
  parkourActions: true,
  parkour: ParkourInfo(available: true, room: 5),
);

void main() {
  for (final size in const [Size(1920, 1080), Size(1024, 700)]) {
    testWidgets('${size.width.toInt()}×${size.height.toInt()}: Роза → «Комната назад», проверка и правило',
        (tester) async {
      late ParkourFakeLink link;
      final container = await pumpDirronlive(
        tester,
        MemoryJsonStore(),
        size: size,
        overrides: [
          minecraftLinkProvider.overrideWith(() => link = ParkourFakeLink(_ready)),
        ],
      );

      await openSection(tester, 'modes');
      await tester.tap(find.byKey(const ValueKey('open-dirron_parkour_100')));
      await tester.pumpAndSettle();
      expectNoFlutterError(tester, 'экран паркура');
      expect(find.text('Dirron Parkour: 100 комнат'), findsOneWidget);
      expect(find.textContaining('комната 5 из 100'), findsOneWidget);

      // Перейти в комнату 12.
      await tester.enterText(find.byKey(const Key('parkour-room-field')), '12');
      await tester.tap(find.byKey(const Key('parkour-goto')));
      await tester.pumpAndSettle();
      expect(find.text('Комната 5 → 12'), findsOneWidget);
      expect(link.room, 12);

      // Подарок «Роза» по названию (каталога ещё нет).
      await tester.enterText(find.byKey(const Key('gift-search')), 'роз');
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.byKey(const Key('gift-option-Роза')));
      await tester.tap(find.byKey(const Key('gift-option-Роза')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('selected-gift')), findsOneWidget);

      // Действие «Комната назад» (выбрано по умолчанию — выбираем явно).
      await tester.ensureVisible(find.byKey(const Key('action-room_back')));
      await tester.tap(find.byKey(const Key('action-room_back')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('param-rooms-value')), findsOneWidget);

      await tester.ensureVisible(find.byKey(const Key('rule-test')));
      await tester.tap(find.byKey(const Key('rule-test')));
      await tester.pumpAndSettle();
      expectNoFlutterError(tester, 'после проверки');
      expect(find.text('Тест · Комната 12 → 11'), findsOneWidget);
      expect(link.room, 11);
      expect(link.sent.last['test'], isTrue);
      final record = container.read(eventLogProvider).events.first;
      expect(record.actionText, 'Тест · Комната 12 → 11');

      await tester.ensureVisible(find.byKey(const Key('rule-save')));
      await tester.tap(find.byKey(const Key('rule-save')));
      await tester.pumpAndSettle();
      final rules = container.read(parkourRulesProvider).rules;
      expect(rules, hasLength(1));
      expect(rules.single.giftName, 'Роза');
      expect(rules.single.actionId, 'room_back');
      expect(find.text('Роза → Комната назад'), findsOneWidget);

      // Проверка из списка правил.
      final testButton = find.byKey(Key('rule-test-${rules.single.id}'));
      await tester.ensureVisible(testButton);
      await tester.tap(testButton);
      await tester.pumpAndSettle();
      expect(find.text('Тест · Комната 11 → 10'), findsOneWidget);

      // Вкладка каталога и описание карты открываются без ошибок.
      await tester.ensureVisible(find.byKey(const Key('parkour-tab-catalog')));
      await tester.tap(find.byKey(const Key('parkour-tab-catalog')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('catalog-refresh')), findsOneWidget);
      await tester.tap(find.byKey(const Key('parkour-tab-about')));
      await tester.pumpAndSettle();
      expectNoFlutterError(tester, 'вкладки паркура');

      // История: запись «Тест · Комната 12 → 11».
      await openSection(tester, 'history');
      expect(find.text('Тест · Комната 12 → 11'), findsOneWidget);
      expect(find.text('Тест · Комната 11 → 10'), findsOneWidget);

      await closeDirronlive(tester, container);
    });
  }

  testWidgets('без мира кнопки показывают причину, а не молчат', (tester) async {
    final container = await pumpDirronlive(
      tester,
      MemoryJsonStore(),
      size: const Size(1024, 700),
      overrides: [fakeLink(const MinecraftLinkState())],
    );
    await openSection(tester, 'modes');
    await tester.tap(find.byKey(const ValueKey('open-dirron_parkour_100')));
    await tester.pumpAndSettle();
    expect(find.textContaining('Связь с игрой выключена'), findsOneWidget);
    await tester.ensureVisible(find.byKey(const Key('rule-test')));
    await tester.tap(find.byKey(const Key('rule-test')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('rule-test-result')), findsOneWidget);
    expect(container.read(eventLogProvider).events, isEmpty);

    // Назад к сетке режимов.
    await tester.ensureVisible(find.byKey(const Key('parkour-back')));
    await tester.tap(find.byKey(const Key('parkour-back')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('mode-maze_escape')), findsOneWidget);
    await closeDirronlive(tester, container);
  });
}
