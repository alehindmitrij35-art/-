// Правила «подарок → действие» против настоящего WebSocket и «поддельного
// мода» 2.0, который ведёт себя как карта Dirron Parkour.

import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/core/events/delivery_status.dart';
import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/core/providers.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/minecraft/link_protocol.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:dirronlive/features/parkour/action_catalog.dart';
import 'package:dirronlive/features/parkour/gift_catalog.dart';
import 'package:dirronlive/features/parkour/parkour_engine.dart';
import 'package:dirronlive/features/parkour/parkour_rules.dart';
import 'package:dirronlive/features/settings/settings_controller.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fake_mod.dart';
import 'support/memory_store.dart';

class FakeFetcher implements GiftCatalogFetcher {
  List<CatalogGift> gifts = const [];
  CatalogFetchException? error;
  int calls = 0;

  @override
  Future<List<CatalogGift>> fetch({required String uniqueId, String? apiKey}) async {
    calls++;
    if (error != null) throw error!;
    return gifts;
  }
}

class Rig {
  Rig._(this.container, this.store, this.fetcher);

  static Future<Rig> start({MemoryJsonStore? store, Duration timeout = const Duration(seconds: 1)}) async {
    final memory = store ?? MemoryJsonStore();
    final fetcher = FakeFetcher();
    final container = createAppContainer(
      await loadInitialData(memory),
      overrides: [
        minecraftLinkConfigProvider.overrideWithValue(MinecraftLinkConfig(
          port: 0,
          ackTimeout: timeout,
          pingInterval: const Duration(seconds: 1),
        )),
        giftCatalogFetcherProvider.overrideWithValue(fetcher),
      ],
    );
    final rig = Rig._(container, memory, fetcher);
    await rig.container.read(minecraftLinkProvider.notifier).start();
    return rig;
  }

  final ProviderContainer container;
  final MemoryJsonStore store;
  final FakeFetcher fetcher;
  FakeMod? mod;

  ParkourEngine get engine => container.read(parkourEngineProvider);
  ParkourRulesController get rules => container.read(parkourRulesProvider.notifier);
  List<GiftEvent> get events => container.read(eventLogProvider).events;

  Future<FakeMod> connectMod({int room = 12}) async {
    final m = await FakeMod.connect(container.read(minecraftLinkProvider).port!);
    m.respondToActions = true;
    m.helloParkour(room: room);
    await waitFor(() => container.read(minecraftLinkProvider).parkourReady, reason: 'карта готова');
    mod = m;
    return m;
  }

  GiftRule rule(String gift, String action, {Map<String, Object?> params = const {}, SeriesMode series = SeriesMode.once, int limit = 5, String? giftId}) {
    final a = parkourActionById(action)!;
    return GiftRule(
      id: newRuleId(),
      giftName: gift,
      giftId: giftId,
      actionId: action,
      params: a.normalize({...a.defaults(), ...params}),
      seriesMode: series,
      limit: limit,
    );
  }

  void tiktokGift(String name, {int count = 1, String? comboId, bool active = false, String? giftId, String viewer = 'Alex'}) =>
      container.read(eventBusProvider).publish(GiftEvent(
            id: generateEventId(),
            createdAt: DateTime.now(),
            source: EventSource.tiktok,
            viewerName: viewer,
            giftName: name,
            count: count,
            comboId: comboId,
            comboActive: active,
            giftId: giftId,
          ));

  Future<void> close() async {
    await mod?.close();
    await container.read(minecraftLinkProvider.notifier).stop();
    await container.read(eventLogProvider.notifier).flush();
    container.dispose();
  }
}

void main() {
  test('«Проверить в игре»: комната 12 → 11 и запись «Тест · Комната 12 → 11»', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 12);
    final outcome = await rig.engine.test(rig.rule('Роза', 'room_back'));

    expect(outcome.ok, isTrue);
    expect(outcome.text, 'Тест · Комната 12 → 11');
    expect(mod.actions, hasLength(1));
    expect(mod.actions.single['action'], 'room_back');
    expect(mod.actions.single['test'], isTrue);
    expect((mod.actions.single['params'] as Map)['rooms'], 1);
    expect(mod.room, 11);

    final record = rig.events.first;
    expect(record.source, EventSource.test);
    expect(record.actionText, 'Тест · Комната 12 → 11');
    expect(record.delivery, DeliveryStatus.delivered);
    expect(mod.gifts, isEmpty, reason: 'проверка не показывает подарок в игре');
    await waitFor(() => rig.container.read(minecraftLinkProvider).parkour.room == 11,
        reason: 'программа знает новую комнату');
    await rig.close();
  });

  test('серия «Роза ×5» запускает действие один раз — после конца серии', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 12);
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));

    for (var n = 1; n <= 5; n++) {
      rig.tiktokGift('Роза', count: n, comboId: 'c1', active: true, giftId: '5655');
      await Future<void>.delayed(const Duration(milliseconds: 20));
    }
    expect(mod.actions, isEmpty, reason: 'пока серия идёт — ничего');
    rig.tiktokGift('Роза', count: 5, comboId: 'c1', active: false, giftId: '5655');
    await waitFor(() => rig.events.first.actionState == ActionState.done, reason: 'результат');
    // Повтор конца серии не запускает действие второй раз.
    rig.tiktokGift('Роза', count: 5, comboId: 'c1', active: false, giftId: '5655');
    await Future<void>.delayed(const Duration(milliseconds: 150));

    expect(mod.actions, hasLength(1));
    expect(rig.events.first.giftText, 'Роза ×5');
    expect(rig.events.first.actionText, 'Комната 12 → 11');
    await rig.close();
  });

  test('«За каждый подарок» с лимитом 3: серия ×5 → три действия, «Комната 12 → 9 (×3)»', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 12);
    await rig.rules.upsert(rig.rule('Роза', 'room_back', series: SeriesMode.perGift, limit: 3));
    rig.tiktokGift('Роза', count: 5, comboId: 'c2');
    await waitFor(() => rig.events.first.actionState == ActionState.done, reason: 'результат');
    expect(mod.actions, hasLength(3));
    expect(rig.events.first.actionText, 'Комната 12 → 9 (×3)');
    await rig.close();
  });

  test('два независимых подарка — два действия; ID подарка важнее названия', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 30);
    await rig.rules.upsert(rig.rule('Роза', 'room_forward', giftId: '5655'));
    rig.tiktokGift('Роза', giftId: '5655');
    rig.tiktokGift('Роза', giftId: '5655', viewer: 'Bob');
    rig.tiktokGift('Роза', giftId: '9999'); // другой подарок с тем же названием
    await waitFor(() => mod.actions.length == 2, reason: 'два действия');
    await Future<void>.delayed(const Duration(milliseconds: 150));
    expect(mod.actions, hasLength(2));
    expect(mod.room, 32);
    await rig.close();
  });

  test('без мира и без мода действие не выполняется, причина видна', () async {
    final rig = await Rig.start();
    final outcome = await rig.engine.test(rig.rule('Роза', 'room_back'));
    expect(outcome.ok, isFalse);
    expect(outcome.text, contains('не подключён'));
    expect(rig.events, isEmpty);

    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    rig.tiktokGift('Роза');
    await waitFor(() => rig.events.isNotEmpty && rig.events.first.actionState == ActionState.skipped,
        reason: 'пропуск');
    expect(rig.events.first.actionText, contains('не подключён'));
    await rig.close();
  });

  test('режим выключен — правила не срабатывают', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod();
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    await rig.rules.setModeActive(false);
    rig.tiktokGift('Роза');
    await Future<void>.delayed(const Duration(milliseconds: 200));
    expect(mod.actions, isEmpty);
    expect(rig.events.first.actionText, isNull);
    await rig.close();
  });

  test('«Второй шанс от чата» отменяет помеху во время отсчёта', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 20);
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    await rig.rules.upsert(rig.rule('Сердце', 'second_chance', params: {'seconds': 2}));

    rig.tiktokGift('Роза', viewer: 'Troll');
    await waitFor(() => mod.countdowns.isNotEmpty, reason: 'отсчёт в игре');
    expect(mod.countdowns.first['seconds'], 2);
    rig.tiktokGift('Сердце', viewer: 'Helper');
    await waitFor(() => mod.countdowns.length == 2, reason: 'отмена отсчёта');
    await Future<void>.delayed(const Duration(milliseconds: 2300));

    expect(mod.actions, isEmpty, reason: 'помеха отменена');
    expect(mod.room, 20);
    final rose = rig.events.firstWhere((e) => e.giftName == 'Роза');
    final heart = rig.events.firstWhere((e) => e.giftName == 'Сердце');
    expect(rose.actionState, ActionState.skipped);
    expect(rose.actionText, contains('Helper'));
    expect(heart.actionText, contains('Отменил «Комната назад»'));
    await rig.close();
  });

  test('без «Второго шанса» помеха срабатывает после отсчёта', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 20);
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    await rig.rules.upsert(rig.rule('Сердце', 'second_chance', params: {'seconds': 1}));
    rig.tiktokGift('Роза');
    await waitFor(() => mod.actions.length == 1, reason: 'выполнено после отсчёта');
    expect(mod.room, 19);
    await rig.close();
  });

  test('СУПЕР СИЛЬНЫЙ ТОЛЧОК: параметры уходят в мод, результат в истории', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod();
    final outcome = await rig.engine.test(rig.rule('Лев', 'super_push', params: {'direction': 'right'}));
    expect(outcome.text, 'Тест · Суперсильный толчок вправо');
    final params = (mod.actions.single['params'] as Map).cast<String, Object?>();
    expect(params, {'direction': 'right', 'strength': 3.0, 'lift': 0.8});
    await rig.close();
  });

  test('переход в комнату и мод без ответа', () async {
    final rig = await Rig.start(timeout: const Duration(milliseconds: 300));
    final mod = await rig.connectMod(room: 5);
    final go = await rig.engine.goToRoom(12);
    expect(go.ok, isTrue);
    expect(go.text, 'Комната 5 → 12');
    mod.respondToActions = false;
    final outcome = await rig.engine.test(rig.rule('Роза', 'room_back'));
    expect(outcome.ok, isFalse);
    expect(outcome.text, contains('не ответила'));
    expect(rig.events.first.delivery, DeliveryStatus.unconfirmed);
    await rig.close();
  });

  test('правила сохраняются и читаются после перезапуска', () async {
    final store = MemoryJsonStore();
    var rig = await Rig.start(store: store);
    await rig.rules.upsert(rig.rule('Роза', 'push', params: {'direction': 'back', 'strength': 2.5}));
    await rig.rules.setModeActive(false);
    await rig.close();

    rig = await Rig.start(store: store);
    final state = rig.container.read(parkourRulesProvider);
    expect(state.modeActive, isFalse);
    expect(state.rules.single.actionTitle, 'Толчок');
    expect(state.rules.single.params, {'direction': 'back', 'strength': 2.5});
    await rig.close();
  });

  test('каталог: три набора совпали — «Все подарки … доступны»; ID подставляются в правила', () async {
    final rig = await Rig.start();
    await rig.container.read(settingsProvider.notifier).saveNickname('@dirron');
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    rig.fetcher.gifts = const [
      CatalogGift(id: '5655', name: 'Rose', diamonds: 1),
      CatalogGift(id: '5487', name: 'Finger Heart', diamonds: 5),
      CatalogGift(id: '5655', name: 'Rose', diamonds: 1),
    ];
    final report = await rig.container.read(giftCatalogProvider.notifier).refreshAndCheck();
    expect(report.fetched, isTrue);
    expect(report.connectorCount, 2);
    expect(report.savedCount, 2);
    expect(report.editorCount, 2);
    expect(report.allAvailable, isTrue);
    expect(rig.store.files.containsKey(GiftCatalogRepository.fileName), isTrue);
    expect(rig.container.read(parkourRulesProvider).rules.single.giftId, '5655');

    // Подарок не из каталога во время эфира — пометка в истории.
    rig.tiktokGift('Мистика', giftId: '424242');
    await waitFor(() => rig.events.isNotEmpty && rig.events.first.unknownGift, reason: 'пометка');
    expect(rig.events.first.actionText, contains('обновите каталог'));

    // Ошибка сети: каталог остаётся прежним, «все доступны» не пишется.
    rig.fetcher.error = const CatalogFetchException('network', 'Ошибка сети: ENOTFOUND');
    final failed = await rig.container.read(giftCatalogProvider.notifier).refreshAndCheck();
    expect(failed.allAvailable, isFalse);
    expect(failed.error, contains('ENOTFOUND'));
    expect(rig.container.read(giftCatalogProvider).catalog.gifts, hasLength(2));
    await rig.close();
  });

  test('каталог без ника не запрашивается', () async {
    final rig = await Rig.start();
    final report = await rig.container.read(giftCatalogProvider.notifier).refreshAndCheck();
    expect(report.allAvailable, isFalse);
    expect(report.error, contains('ник'));
    expect(rig.fetcher.calls, 0);
    await rig.close();
  });

  test('ответ коннектора --fetch-gifts разбирается', () {
    final gifts = NodeGiftCatalogFetcher.parseFetchOutput(
        '{"type":"gifts","gifts":[{"id":"5655","name":"Rose","diamonds":1,"image":"https://x/r.png"},'
        '{"id":"0","name":"Bad"}]}\n');
    expect(gifts.map((g) => g.id), ['5655']);
    expect(gifts.single.displayName, 'Роза');
    expect(
      () => NodeGiftCatalogFetcher.parseFetchOutput(
          '{"type":"status","status":"offline","kind":"offline","message":"Эфир не найден"}'),
      throwsA(isA<CatalogFetchException>().having((e) => e.kind, 'kind', 'offline')),
    );
  });

  test('каталог действий: 23 действия, «Боковой порыв» заменён «Толчком»', () {
    expect(parkourActions, hasLength(23));
    final ids = parkourActions.map((a) => a.id).toSet();
    expect(ids, hasLength(23));
    expect(ids, containsAll(['push', 'to_last_level', 'to_first_level', 'super_push']));
    expect(parkourActions.map((a) => a.title), isNot(contains('Боковой порыв')));
    expect(parkourActionById('super_push')!.defaults(), {'direction': 'forward', 'strength': 3.0, 'lift': 0.8});
  });

  test('результаты нескольких действий склеиваются', () {
    ModActionResult r(String text) => ModActionResult(id: 'x', ok: true, result: text);
    expect(combineResults([r('Комната 12 → 11')]), 'Комната 12 → 11');
    expect(combineResults([r('Комната 12 → 11'), r('Комната 11 → 10')]), 'Комната 12 → 10 (×2)');
    expect(combineResults([r('Толчок влево'), null]), 'Толчок влево — выполнено 1 из 2');
    expect(combineResults([null]), contains('не ответила'));
  });
}
