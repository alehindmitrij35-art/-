import 'dart:io';

import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/core/storage/app_paths.dart';
import 'package:dirronlive/core/storage/json_file_store.dart';
import 'package:dirronlive/core/storage/storage_exception.dart';
import 'package:dirronlive/features/events/event_history_repository.dart';
import 'package:dirronlive/features/settings/app_settings.dart';
import 'package:dirronlive/features/settings/settings_repository.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  late Directory temp;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('dirronlive_test_');
  });

  tearDown(() async {
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  String join(String a, String b) => '$a${Platform.pathSeparator}$b';

  test('папка данных — %APPDATA%\\Dirronlive', () {
    final dir = resolveDataDirectory(
        environment: {'APPDATA': r'C:\Users\Тест\AppData\Roaming'});
    expect(dir.path, startsWith(r'C:\Users\Тест\AppData\Roaming'));
    expect(dir.path, endsWith(appDataFolderName));
  });

  test('первый запуск: папки ещё нет — пустая история, без ошибок', () async {
    final store = FileJsonStore(Directory(join(temp.path, 'нет_такой_папки')));
    final data = await loadInitialData(store);
    expect(data.history, isEmpty);
    expect(data.warnings, isEmpty);
  });

  test('история и ник реально пишутся в файлы и читаются обратно', () async {
    final dir = Directory(join(temp.path, 'Дирронлайв данные'));
    final store = FileJsonStore(dir);
    final events = [
      for (var i = 0; i < 3; i++)
        GiftEvent(
          id: generateEventId(),
          createdAt: DateTime(2026, 11, 23, 0, 31, i),
          source: EventSource.test,
          viewerName: 'Тестовый зритель',
          giftName: 'Роза',
          count: 1,
        ),
    ].reversed.toList();

    await EventHistoryRepository(store).save(events);
    await SettingsRepository(store)
        .save(const AppSettings(tiktokNickname: 'dirron'));

    expect(File(join(dir.path, 'history.json')).existsSync(), isTrue);
    expect(File(join(dir.path, 'settings.json')).existsSync(), isTrue);
    expect(File(join(dir.path, 'history.json.tmp')).existsSync(), isFalse);

    final reloaded = await loadInitialData(FileJsonStore(dir));
    expect(reloaded.history, events);
    expect(reloaded.settings.tiktokNickname, 'dirron');
    expect(reloaded.warnings, isEmpty);
  });

  test('повторная запись заменяет файл, а не дописывает', () async {
    final store = FileJsonStore(temp);
    await SettingsRepository(store)
        .save(const AppSettings(tiktokNickname: 'first'));
    await SettingsRepository(store)
        .save(const AppSettings(tiktokNickname: 'second'));
    final loaded = await SettingsRepository(store).load();
    expect(loaded.settings.tiktokNickname, 'second');
  });

  test('повреждённый файл переименовывается, программа стартует', () async {
    File(join(temp.path, 'history.json')).writeAsStringSync('{"events": [');
    final data = await loadInitialData(FileJsonStore(temp));
    expect(data.history, isEmpty);
    expect(data.warnings.single, contains('повреждён'));
    final names = temp.listSync().map((e) => e.uri.pathSegments.last);
    expect(names.any((n) => n.startsWith('history.json.broken-')), isTrue);
  });

  test('файл с BOM (после правки в Блокноте) читается', () async {
    File(join(temp.path, 'settings.json'))
        .writeAsStringSync('\uFEFF{"version":1,"tiktokNickname":"dirron"}');
    final loaded = await SettingsRepository(FileJsonStore(temp)).load();
    expect(loaded.settings.tiktokNickname, 'dirron');
  });

  test('ошибка записи превращается в StorageException на русском', () async {
    final blocker = File(join(temp.path, 'blocker'))..writeAsStringSync('x');
    final store = FileJsonStore(Directory(join(blocker.path, 'data')));
    await expectLater(
      SettingsRepository(store).save(const AppSettings(tiktokNickname: 'x')),
      throwsA(isA<StorageException>().having(
          (e) => e.message, 'message', contains('Не удалось записать файл'))),
    );
  });
}
