// Переходы: вкладки, кнопка «Настройки», полоса состояния → нужная секция
// настроек (прокрутка и подсветка), состояния связи с игрой на экранах.

import 'package:dirronlive/core/events/delivery_status.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/minecraft/link_state.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:dirronlive/features/settings/settings_controller.dart';
import 'package:dirronlive/ui/screens/history_screen.dart';
import 'package:dirronlive/ui/screens/live_screen.dart';
import 'package:dirronlive/ui/screens/modes_screen.dart';
import 'package:dirronlive/ui/screens/settings_screen.dart';
import 'package:dirronlive/ui/widgets/test_gift_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';
import 'support/test_app.dart';

bool sectionHighlighted(WidgetTester tester, Key sectionKey) => find
    .descendant(of: find.byKey(sectionKey), matching: find.text('Здесь'))
    .evaluate()
    .isNotEmpty;

void main() {
  testWidgets('вкладки и «Вся история»', (tester) async {
    final container = await pumpDirronlive(tester, MemoryJsonStore());
    await openSection(tester, 'modes');
    expect(find.byType(ModesScreen), findsOneWidget);
    await openSection(tester, 'history');
    expect(find.byType(HistoryScreen), findsOneWidget);
    await openSection(tester, 'live');
    await tester.tap(find.byKey(const Key('open-history')));
    await tester.pumpAndSettle();
    expect(find.byType(HistoryScreen), findsOneWidget);
    await openSection(tester, 'settings');
    expect(find.byType(SettingsScreen), findsOneWidget);
    await closeDirronlive(tester, container);
  });

  for (final size in const [Size(1920, 1080), Size(1024, 700)]) {
    testWidgets(
        'полоса состояния ведёт к нужной секции настроек '
        '(${size.width.toInt()}×${size.height.toInt()})', (tester) async {
      final container =
          await pumpDirronlive(tester, MemoryJsonStore(), size: size);

      await tester.tap(find.byKey(const Key('strip-minecraft')));
      await tester.pumpAndSettle(const Duration(milliseconds: 100));
      expect(find.byType(SettingsScreen), findsOneWidget);
      expect(sectionHighlighted(tester, SettingsScreen.minecraftSectionKey),
          isTrue);
      expect(sectionHighlighted(tester, SettingsScreen.tiktokSectionKey),
          isFalse);
      expect(find.byKey(SettingsScreen.linkToggleKey).hitTestable(),
          findsOneWidget);

      // Подсветка гаснет сама.
      await tester.pump(const Duration(seconds: 3));
      await tester.pumpAndSettle();
      expect(sectionHighlighted(tester, SettingsScreen.minecraftSectionKey),
          isFalse);

      await openSection(tester, 'live');
      await tester.tap(find.byKey(const Key('strip-tiktok')));
      await tester.pumpAndSettle(const Duration(milliseconds: 100));
      expect(sectionHighlighted(tester, SettingsScreen.tiktokSectionKey),
          isTrue);
      expect(find.byKey(SettingsScreen.nicknameFieldKey).hitTestable(),
          findsOneWidget);

      await closeDirronlive(tester, container);
    });
  }

  testWidgets('состояния связи одинаковы на «Эфире» и в настройках',
      (tester) async {
    final container = await pumpDirronlive(
      tester,
      MemoryJsonStore(),
      overrides: [fakeLink(const MinecraftLinkState())],
    );
    final fake =
        container.read(minecraftLinkProvider.notifier) as FakeLinkController;

    const states = {
      LinkPhase.off: 'Связь выключена',
      LinkPhase.waitingForMod: 'Ожидание мода',
      LinkPhase.modConnected: 'Мод подключён • открой одиночный мир',
      LinkPhase.worldReady: 'Мир готов',
    };
    for (final entry in states.entries) {
      fake.show(MinecraftLinkState(
        phase: entry.key,
        port: 8765,
        modVersion: '1.0.0',
        minecraftVersion: '1.21.1',
      ));
      await openSection(tester, 'live');
      expect(
        find.descendant(
          of: find.byKey(const Key('strip-minecraft')),
          matching: find.text(entry.value),
        ),
        findsOneWidget,
        reason: entry.key.name,
      );
      // TikTok не зависит от Minecraft.
      expect(
        find.descendant(
          of: find.byKey(const Key('strip-tiktok')),
          matching: find.text('Не подключено'),
        ),
        findsOneWidget,
      );
      await openSection(tester, 'settings');
      expect(
        find.descendant(
          of: find.byKey(const Key('link-status')),
          matching: find.text(entry.value),
        ),
        findsOneWidget,
      );
    }
    await closeDirronlive(tester, container);
  });

  testWidgets('порт занят: понятная ошибка и «Повторить»', (tester) async {
    final container = await pumpDirronlive(
      tester,
      MemoryJsonStore(),
      overrides: [
        fakeLink(const MinecraftLinkState(
          phase: LinkPhase.error,
          port: 8765,
          errorTitle: 'Порт 8765 занят',
          errorMessage: 'Порт 8765 уже занят другой программой.',
        )),
      ],
    );
    final fake =
        container.read(minecraftLinkProvider.notifier) as FakeLinkController;
    expect(
      find.descendant(
        of: find.byKey(const Key('strip-minecraft')),
        matching: find.text('Порт 8765 занят'),
      ),
      findsOneWidget,
    );
    await tester.tap(find.byKey(const Key('strip-minecraft')));
    await tester.pumpAndSettle();
    expect(find.textContaining('уже занят другой программой'), findsOneWidget);
    await tester.tap(find.byKey(SettingsScreen.linkRetryKey));
    await tester.pumpAndSettle();
    expect(fake.retries, 1);
    await closeDirronlive(tester, container);
  });

  testWidgets('кнопка включения связи запоминает выбор', (tester) async {
    final store = MemoryJsonStore();
    final container = await pumpDirronlive(
      tester,
      store,
      overrides: [fakeLink(const MinecraftLinkState())],
    );
    final fake =
        container.read(minecraftLinkProvider.notifier) as FakeLinkController;

    await openSection(tester, 'settings');
    await tester.ensureVisible(find.byKey(SettingsScreen.linkToggleKey));
    await tester.pumpAndSettle();
    expect(find.text('Включить связь с игрой'), findsOneWidget);
    await tester.tap(find.byKey(SettingsScreen.linkToggleKey));
    await tester.pumpAndSettle();
    expect(fake.starts, 1);
    expect(container.read(settingsProvider).minecraftLinkEnabled, isTrue);
    expect(find.text('Выключить связь'), findsOneWidget);
    expect(find.text('Ожидание мода'), findsOneWidget);

    await tester.tap(find.byKey(SettingsScreen.linkToggleKey));
    await tester.pumpAndSettle();
    expect(fake.stops, 1);
    expect(container.read(settingsProvider).minecraftLinkEnabled, isFalse);
    await closeDirronlive(tester, container);
  });

  testWidgets('статусы доставки видны в ленте и в истории', (tester) async {
    final container = await pumpDirronlive(tester, MemoryJsonStore());
    final button = find.byKey(TestGiftButton.buttonKey);
    for (var i = 0; i < 4; i++) {
      await tester.tap(button);
    }
    await tester.pumpAndSettle();

    final log = container.read(eventLogProvider.notifier);
    final ids = container.read(eventLogProvider).events.map((e) => e.id).toList();
    log.setDelivery(ids[0], DeliveryStatus.sending);
    log.setDelivery(ids[1], DeliveryStatus.delivered);
    log.setDelivery(ids[2], DeliveryStatus.unconfirmed);
    await tester.pumpAndSettle();

    for (final screen in ['live', 'history']) {
      await openSection(tester, screen);
      expect(find.text('Отправляется'), findsOneWidget, reason: screen);
      expect(find.text('Доставлено в игру'), findsOneWidget, reason: screen);
      expect(find.text('Доставка не подтверждена'), findsOneWidget,
          reason: screen);
      expect(find.text('Только в журнале'), findsOneWidget, reason: screen);
    }
    expect(find.byType(LiveScreen), findsNothing);
    await closeDirronlive(tester, container);
  });
}
