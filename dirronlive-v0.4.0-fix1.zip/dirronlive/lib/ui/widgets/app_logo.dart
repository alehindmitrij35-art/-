import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// Значок приложения: тот же рисунок, что и у иконки Windows.
class AppLogo extends StatelessWidget {
  const AppLogo({super.key, this.size = 36});

  static const assetPath = 'assets/icon/dirronlive.png';
  static const logoKey = Key('app-logo');

  final double size;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      assetPath,
      key: logoKey,
      width: size,
      height: size,
      filterQuality: FilterQuality.high,
      semanticLabel: 'Значок Dirronlive',
      // Если картинка вдруг не загрузится, верхняя строка не ломается.
      errorBuilder: (context, error, stackTrace) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: AppColors.surfaceHigh,
          borderRadius: BorderRadius.circular(size * 0.22),
        ),
        alignment: Alignment.center,
        child: const Text(
          'D',
          style: TextStyle(
            color: AppColors.accent,
            fontWeight: FontWeight.w900,
            fontSize: 20,
          ),
        ),
      ),
    );
  }
}
