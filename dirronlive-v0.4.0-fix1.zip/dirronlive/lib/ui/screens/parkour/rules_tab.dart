import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers.dart';
import '../../../features/parkour/action_catalog.dart';
import '../../../features/parkour/gift_catalog.dart';
import '../../../features/parkour/parkour_engine.dart';
import '../../../features/parkour/parkour_rules.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common.dart';

/// Значок подарка: картинка из каталога или общий значок.
class GiftAvatar extends StatelessWidget {
  const GiftAvatar({super.key, this.imageUrl, this.size = 36});

  final String? imageUrl;
  final double size;

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppColors.accentAlt.withAlpha(36),
        shape: BoxShape.circle,
      ),
      child: Icon(Icons.redeem_rounded, color: AppColors.accentAlt, size: size * 0.55),
    );
    final url = imageUrl;
    if (url == null) return fallback;
    return ClipOval(
      child: Image.network(
        url,
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stack) => fallback,
      ),
    );
  }
}

/// Черновик правила в редакторе.
class _Draft {
  String? ruleId;
  String? giftName;
  String? giftId;
  String? imageUrl;
  String actionId = 'room_back';
  Map<String, Object> params = parkourActionById('room_back')!.defaults();
  SeriesMode series = SeriesMode.once;
  int limit = 5;
  bool enabled = true;

  ParkourAction get action => parkourActionById(actionId)!;

  void setAction(String id) {
    actionId = id;
    params = parkourActionById(id)!.defaults();
  }

  GiftRule toRule() => GiftRule(
        id: ruleId ?? newRuleId(),
        giftName: giftName ?? 'Проверка',
        giftId: giftId,
        imageUrl: imageUrl,
        actionId: actionId,
        params: action.normalize(params),
        seriesMode: series,
        limit: limit,
        enabled: enabled,
      );

  static _Draft from(GiftRule rule) => _Draft()
    ..ruleId = rule.id
    ..giftName = rule.giftName
    ..giftId = rule.giftId
    ..imageUrl = rule.imageUrl
    ..actionId = rule.actionId
    ..params = Map.of(rule.params)
    ..series = rule.seriesMode
    ..limit = rule.limit
    ..enabled = rule.enabled;
}

/// «Действия за подарки»: редактор правила и список правил.
class RulesTab extends ConsumerStatefulWidget {
  const RulesTab({super.key});

  @override
  ConsumerState<RulesTab> createState() => _RulesTabState();
}

class _RulesTabState extends ConsumerState<RulesTab> {
  _Draft _draft = _Draft();
  final _search = TextEditingController();
  bool _testing = false;
  ActionOutcome? _testResult;
  final Map<String, ActionOutcome> _ruleResults = {};
  final Set<String> _ruleTesting = {};

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _pickGift({required String name, String? id, String? image}) {
    setState(() {
      _draft.giftName = name;
      _draft.giftId = id;
      _draft.imageUrl = image;
      _search.clear();
    });
  }

  Future<void> _testDraft() async {
    setState(() {
      _testing = true;
      _testResult = null;
    });
    final result = await ref.read(parkourEngineProvider).test(_draft.toRule());
    if (!mounted) return;
    setState(() {
      _testing = false;
      _testResult = result;
    });
  }

  Future<void> _testRule(GiftRule rule) async {
    setState(() => _ruleTesting.add(rule.id));
    final result = await ref.read(parkourEngineProvider).test(rule);
    if (!mounted) return;
    setState(() {
      _ruleTesting.remove(rule.id);
      _ruleResults[rule.id] = result;
    });
  }

  Future<void> _save() async {
    final name = _draft.giftName;
    if (name == null) return;
    var rule = _draft.toRule();
    // Один подарок — одно правило: правило того же подарка заменяется.
    final existing = ref
        .read(parkourRulesProvider)
        .rules
        .where((r) => r.id != rule.id && _sameGift(r, rule))
        .firstOrNull;
    if (existing != null) {
      rule = GiftRule(
        id: existing.id,
        giftName: rule.giftName,
        giftId: rule.giftId ?? existing.giftId,
        imageUrl: rule.imageUrl ?? existing.imageUrl,
        actionId: rule.actionId,
        params: rule.params,
        seriesMode: rule.seriesMode,
        limit: rule.limit,
        enabled: rule.enabled,
      );
    }
    final error = await ref.read(parkourRulesProvider.notifier).upsert(rule);
    if (!mounted) return;
    final notices = ref.read(noticeServiceProvider);
    if (error != null) {
      notices.error(error);
      return;
    }
    notices.info(existing != null
        ? 'Правило для «$name» обновлено: ${rule.actionTitle}'
        : 'Правило сохранено: «$name» → ${rule.actionTitle}');
    setState(() => _draft = _Draft.from(rule));
  }

  static bool _sameGift(GiftRule a, GiftRule b) {
    if (a.giftId != null && b.giftId != null) return a.giftId == b.giftId;
    return a.giftName.trim().toLowerCase() == b.giftName.trim().toLowerCase();
  }

  GiftCatalog _catalog = const GiftCatalog();

  @override
  Widget build(BuildContext context) {
    final rules = ref.watch(parkourRulesProvider).rules;
    _catalog = ref.watch(giftCatalogProvider).catalog;
    return LayoutBuilder(builder: (context, constraints) {
      final editor = _editor();
      final list = _rulesList(rules);
      if (constraints.maxWidth >= 980) {
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(flex: 11, child: editor),
            const SizedBox(width: 18),
            Expanded(flex: 9, child: list),
          ],
        );
      }
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [editor, const SizedBox(height: 18), list],
      );
    });
  }

  // ------------------------------------------------------------ редактор

  Widget _editor() {
    final draft = _draft;
    final action = draft.action;
    return Panel(
      key: const Key('rule-editor'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  draft.ruleId == null ? 'Новое правило' : 'Правило: «${draft.giftName}»',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.text),
                ),
              ),
              if (draft.ruleId != null)
                TextButton.icon(
                  key: const Key('rule-new'),
                  onPressed: () => setState(() {
                    _draft = _Draft();
                    _testResult = null;
                  }),
                  icon: const Icon(Icons.add_rounded, size: 18),
                  label: const Text('Новое'),
                ),
            ],
          ),
          const SizedBox(height: 16),
          const _StepTitle('1. Подарок'),
          _giftPicker(),
          const SizedBox(height: 18),
          const _StepTitle('2. Действие'),
          _actionPicker(),
          const SizedBox(height: 8),
          Text(
            action.description,
            key: const Key('action-description'),
            style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textMuted),
          ),
          if (action.params.isNotEmpty) ...[
            const SizedBox(height: 18),
            const _StepTitle('3. Параметры'),
            for (final p in action.params) _paramRow(p),
          ],
          const SizedBox(height: 18),
          _StepTitle(action.params.isEmpty ? '3. Серия подарков' : '4. Серия подарков'),
          _seriesPicker(),
          const SizedBox(height: 20),
          Wrap(
            spacing: 12,
            runSpacing: 10,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              FilledButton.icon(
                key: const Key('rule-test'),
                onPressed: _testing ? null : _testDraft,
                icon: _testing
                    ? const SizedBox(
                        width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.play_arrow_rounded, size: 20),
                label: const Text('Проверить в игре'),
              ),
              OutlinedButton.icon(
                key: const Key('rule-save'),
                onPressed: draft.giftName == null ? null : _save,
                icon: const Icon(Icons.save_rounded, size: 18),
                label: Text(draft.ruleId == null ? 'Сохранить правило' : 'Сохранить изменения'),
              ),
            ],
          ),
          if (draft.giftName == null)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text(
                'Чтобы сохранить правило, выберите подарок. Проверить действие можно и без него.',
                style: TextStyle(fontSize: 12, color: AppColors.textFaint),
              ),
            ),
          if (_testResult != null) ...[
            const SizedBox(height: 12),
            _ResultLine(key: const Key('rule-test-result'), outcome: _testResult!),
          ],
        ],
      ),
    );
  }

  Widget _giftPicker() {
    final catalog = _catalog;
    final query = _search.text.trim();
    final options = <Widget>[];
    if (catalog.gifts.isNotEmpty) {
      for (final g in catalog.gifts.where((g) => g.matchesQuery(query)).take(8)) {
        options.add(_GiftOption(
          key: Key('gift-option-${g.id}'),
          title: g.displayName,
          subtitle: 'ID ${g.id}${g.diamonds > 0 ? ' · ${g.diamonds} алм.' : ''}',
          imageUrl: g.imageUrl,
          onTap: () => _pickGift(name: g.displayName, id: g.id, image: g.imageUrl),
        ));
      }
    }
    if (catalog.gifts.isEmpty || query.isNotEmpty) {
      final lower = query.toLowerCase();
      for (final name in starterGiftNames.where((n) => n.toLowerCase().contains(lower)).take(6)) {
        if (catalog.gifts.any((g) => g.displayName == name)) continue;
        options.add(_GiftOption(
          key: Key('gift-option-$name'),
          title: name,
          subtitle: 'по названию — ID подставится после сверки каталога',
          onTap: () => _pickGift(name: name),
        ));
      }
    }
    if (query.isNotEmpty) {
      final isId = RegExp(r'^\d{2,}$').hasMatch(query);
      final known = catalog.gifts.any((g) => g.id == query ||
          g.displayName.toLowerCase() == query.toLowerCase());
      if (!known) {
        options.add(_GiftOption(
          key: const Key('gift-option-custom'),
          title: isId ? 'Подарок с ID $query' : 'Свой подарок «$query»',
          subtitle: isId ? 'срабатывает по ID' : 'срабатывает по названию',
          icon: Icons.add_rounded,
          onTap: () => isId
              ? _pickGift(name: 'Подарок $query', id: query)
              : _pickGift(name: query),
        ));
      }
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_draft.giftName != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              key: const Key('selected-gift'),
              children: [
                GiftAvatar(imageUrl: _draft.imageUrl),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(
                    '${_draft.giftName}${_draft.giftId == null ? '' : '  ·  ID ${_draft.giftId}'}',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.text),
                  ),
                ),
              ],
            ),
          ),
        TextField(
          key: const Key('gift-search'),
          controller: _search,
          onChanged: (_) => setState(() {}),
          style: const TextStyle(fontSize: 15, color: AppColors.text),
          decoration: appInputDecoration(
            label: _draft.giftName == null ? 'Найти подарок' : 'Выбрать другой подарок',
            hint: 'название или ID, например «Роза» или 5655',
            icon: Icons.search_rounded,
          ),
        ),
        const SizedBox(height: 8),
        if (options.isEmpty)
          const Text('Ничего не найдено', style: TextStyle(fontSize: 13, color: AppColors.textFaint))
        else
          Wrap(spacing: 8, runSpacing: 8, children: options),
      ],
    );
  }

  Widget _actionPicker() {
    Widget group(String title, bool hindrance) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 12, color: AppColors.textFaint)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final a in parkourActions.where((a) => a.hindrance == hindrance))
                  ChoiceChip(
                    key: Key('action-${a.id}'),
                    label: Text(a.title),
                    selected: _draft.actionId == a.id,
                    showCheckmark: false,
                    selectedColor: hindrance ? AppColors.danger : AppColors.accent,
                    labelStyle: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: _draft.actionId == a.id ? AppColors.onAccent : AppColors.text,
                    ),
                    onSelected: (_) => setState(() {
                      _draft.setAction(a.id);
                      _testResult = null;
                    }),
                  ),
              ],
            ),
          ],
        );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        group('Помогают', false),
        const SizedBox(height: 10),
        group('Мешают — помеха (гасится «Щитом», ждёт «Второго шанса»)', true),
      ],
    );
  }

  Widget _paramRow(ActionParam p) {
    final value = p.normalize(_draft.params[p.key]);
    Widget control;
    if (p.kind == ParamKind.choice) {
      control = Wrap(
        spacing: 6,
        runSpacing: 6,
        children: [
          for (final entry in p.choices.entries)
            ChoiceChip(
              key: Key('param-${p.key}-${entry.key}'),
              label: Text(entry.value),
              selected: value == entry.key,
              showCheckmark: false,
              selectedColor: AppColors.accent,
              labelStyle: TextStyle(color: value == entry.key ? AppColors.onAccent : AppColors.text),
              onSelected: (_) => setState(() => _draft.params[p.key] = entry.key),
            ),
        ],
      );
    } else {
      control = _Stepper(
        keyPrefix: 'param-${p.key}',
        text: p.format(value),
        onMinus: () => setState(() => _draft.params[p.key] = p.normalize((value as num) - p.step)),
        onPlus: () => setState(() => _draft.params[p.key] = p.normalize((value as num) + p.step)),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Wrap(
        spacing: 12,
        runSpacing: 6,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          SizedBox(
            width: 150,
            child: Text(p.label, style: const TextStyle(fontSize: 14, color: AppColors.textMuted)),
          ),
          control,
        ],
      ),
    );
  }

  Widget _seriesPicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final mode in SeriesMode.values)
              ChoiceChip(
                key: Key('series-${mode.id}'),
                label: Text(mode.label),
                selected: _draft.series == mode,
                showCheckmark: false,
                selectedColor: AppColors.accent,
                labelStyle: TextStyle(color: _draft.series == mode ? AppColors.onAccent : AppColors.text),
                onSelected: (_) => setState(() => _draft.series = mode),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          _draft.series == SeriesMode.once
              ? 'Серия «${_draft.giftName ?? 'Роза'} ×5» запустит действие один раз — после окончания серии.'
              : 'Каждый подарок серии запускает действие, но не больше ${_draft.limit} раз за серию.',
          style: const TextStyle(fontSize: 12, color: AppColors.textFaint),
        ),
        if (_draft.series == SeriesMode.perGift) ...[
          const SizedBox(height: 8),
          Wrap(
            spacing: 12,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              const SizedBox(
                width: 150,
                child: Text('Не больше за серию', style: TextStyle(fontSize: 14, color: AppColors.textMuted)),
              ),
              _Stepper(
                keyPrefix: 'param-limit',
                text: '${_draft.limit}',
                onMinus: () => setState(() => _draft.limit = (_draft.limit - 1).clamp(1, 100).toInt()),
                onPlus: () => setState(() => _draft.limit = (_draft.limit + 1).clamp(1, 100).toInt()),
              ),
            ],
          ),
        ],
      ],
    );
  }

  // ------------------------------------------------------------ список

  Widget _rulesList(List<GiftRule> rules) {
    return Panel(
      key: const Key('rules-list'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Правила (${rules.length})',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.text),
          ),
          const SizedBox(height: 4),
          const Text(
            'Срабатывают на подарки эфира, когда режим активен и открыт мир DirronParkour.',
            style: TextStyle(fontSize: 13, color: AppColors.textMuted),
          ),
          const SizedBox(height: 12),
          if (rules.isEmpty)
            const NotePanel(
              text: 'Правил пока нет. Выберите подарок и действие слева и нажмите «Сохранить правило».',
            )
          else
            for (final rule in rules) ...[
              _ruleCard(rule),
              const SizedBox(height: 10),
            ],
        ],
      ),
    );
  }

  Widget _ruleCard(GiftRule rule) {
    final action = rule.action;
    final result = _ruleResults[rule.id];
    final testing = _ruleTesting.contains(rule.id);
    final summary = [
      if (action != null && action.params.isNotEmpty) action.summary(rule.params),
      rule.seriesMode == SeriesMode.once ? 'серия — один раз' : 'за каждый подарок, до ${rule.limit}',
    ].join(' · ');
    return Container(
      key: Key('rule-${rule.id}'),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _draft.ruleId == rule.id ? AppColors.surfaceHigh : AppColors.surfaceAlt,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: (action?.hindrance ?? false) ? AppColors.danger.withAlpha(90) : AppColors.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              GiftAvatar(imageUrl: rule.imageUrl, size: 32),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${rule.giftName} → ${rule.actionTitle}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: rule.enabled ? AppColors.text : AppColors.textFaint,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${rule.giftId == null ? 'по названию' : 'ID ${rule.giftId}'} · $summary',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                    ),
                  ],
                ),
              ),
              Switch(
                key: Key('rule-enabled-${rule.id}'),
                value: rule.enabled,
                onChanged: (v) => ref.read(parkourRulesProvider.notifier).setEnabled(rule.id, v),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 4,
            runSpacing: 4,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              TextButton.icon(
                key: Key('rule-test-${rule.id}'),
                onPressed: testing ? null : () => _testRule(rule),
                icon: const Icon(Icons.play_arrow_rounded, size: 18),
                label: const Text('Проверить в игре'),
              ),
              TextButton.icon(
                key: Key('rule-edit-${rule.id}'),
                onPressed: () => setState(() {
                  _draft = _Draft.from(rule);
                  _testResult = null;
                }),
                icon: const Icon(Icons.edit_rounded, size: 16),
                label: const Text('Изменить'),
              ),
              TextButton.icon(
                key: Key('rule-delete-${rule.id}'),
                onPressed: () async {
                  await ref.read(parkourRulesProvider.notifier).remove(rule.id);
                  if (!mounted) return;
                  if (_draft.ruleId == rule.id) setState(() => _draft = _Draft());
                },
                style: TextButton.styleFrom(foregroundColor: AppColors.danger),
                icon: const Icon(Icons.delete_outline_rounded, size: 16),
                label: const Text('Удалить'),
              ),
            ],
          ),
          if (result != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: _ResultLine(key: Key('rule-result-${rule.id}'), outcome: result),
            ),
        ],
      ),
    );
  }
}

class _StepTitle extends StatelessWidget {
  const _StepTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.accent)),
      );
}

class _GiftOption extends StatelessWidget {
  const _GiftOption({
    super.key,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.imageUrl,
    this.icon,
  });

  final String title;
  final String subtitle;
  final String? imageUrl;
  final IconData? icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surfaceAlt,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 260),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null)
                Icon(icon, color: AppColors.accent, size: 26)
              else
                GiftAvatar(imageUrl: imageUrl, size: 28),
              const SizedBox(width: 8),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.text)),
                    Text(subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11, color: AppColors.textFaint)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Stepper extends StatelessWidget {
  const _Stepper({
    required this.keyPrefix,
    required this.text,
    required this.onMinus,
    required this.onPlus,
  });

  final String keyPrefix;
  final String text;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton.outlined(
          key: Key('$keyPrefix-minus'),
          onPressed: onMinus,
          icon: const Icon(Icons.remove_rounded, size: 18),
        ),
        SizedBox(
          width: 84,
          child: Text(
            text,
            key: Key('$keyPrefix-value'),
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.text),
          ),
        ),
        IconButton.outlined(
          key: Key('$keyPrefix-plus'),
          onPressed: onPlus,
          icon: const Icon(Icons.add_rounded, size: 18),
        ),
      ],
    );
  }
}

class _ResultLine extends StatelessWidget {
  const _ResultLine({super.key, required this.outcome});

  final ActionOutcome outcome;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          outcome.ok ? Icons.check_circle_rounded : Icons.error_outline_rounded,
          size: 18,
          color: outcome.ok ? AppColors.success : AppColors.danger,
        ),
        const SizedBox(width: 6),
        Flexible(
          child: Text(
            outcome.text,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: outcome.ok ? AppColors.success : AppColors.danger,
            ),
          ),
        ),
      ],
    );
  }
}
