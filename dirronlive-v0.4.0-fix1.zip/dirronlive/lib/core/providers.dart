import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'events/event_bus.dart';
import 'initial_data.dart';
import 'notices.dart';
import 'storage/json_store.dart';

/// Данные, прочитанные с диска при запуске. Переопределяется в `main.dart`
/// (и в тестах) через [createAppContainer].
final initialDataProvider = Provider<InitialData>(
  (ref) => throw UnimplementedError(
      'initialDataProvider должен быть переопределён при запуске'),
);

final jsonStoreProvider = Provider<JsonStore>(
  (ref) => ref.watch(initialDataProvider).store,
);

/// Единственная шина событий на всё приложение.
final eventBusProvider = Provider<EventBus>((ref) {
  final bus = EventBus();
  ref.onDispose(bus.dispose);
  return bus;
});

/// Часы. В тестах можно подменить на фиксированное время.
final clockProvider = Provider<DateTime Function()>((ref) => DateTime.now);

final scaffoldMessengerKeyProvider =
    Provider<GlobalKey<ScaffoldMessengerState>>(
  (ref) => GlobalKey<ScaffoldMessengerState>(),
);

final noticeServiceProvider = Provider<NoticeService>(
  (ref) => NoticeService(ref.watch(scaffoldMessengerKeyProvider)),
);
