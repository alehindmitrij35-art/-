import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/delivery_status.dart';
import '../../core/events/event_source.dart';
import '../../core/events/gift_event.dart';
import '../../core/providers.dart';
import '../events/event_log.dart';
import '../minecraft/link_protocol.dart';
import '../minecraft/minecraft_link.dart';
import 'action_catalog.dart';
import 'gift_catalog.dart';
import 'parkour_rules.dart';

final parkourEngineProvider = Provider<ParkourEngine>((ref) {
  final engine = ParkourEngine(ref);
  ref.onDispose(engine.dispose);
  return engine;
});

/// Итог «Проверить в игре» или перехода в комнату.
class ActionOutcome {
  const ActionOutcome(this.ok, this.text);

  final bool ok;
  final String text;
}

/// Правила «подарок → действие» на карте Dirron Parkour.
///
/// Слушает шину после журнала и доставки. Срабатывает на завершённые
/// записи: одиночный подарок — сразу, серия — один раз, когда закончилась
/// («Роза ×5»). Каждая запись обрабатывается ровно один раз. Результат
/// из игры («Комната 12 → 11») сохраняется в той же записи истории.
class ParkourEngine {
  ParkourEngine(this._ref) {
    _giftSubscription = _ref.read(eventBusProvider).on<GiftEvent>().listen(_onGift);
    _resultSubscription =
        _ref.read(minecraftLinkProvider.notifier).actionResults.listen(_onResult);
  }

  final Ref<Object?> _ref;
  late final StreamSubscription<GiftEvent> _giftSubscription;
  late final StreamSubscription<ModActionResult> _resultSubscription;
  final Set<String> _processed = {};
  final Map<String, Completer<ModActionResult?>> _waiting = {};
  final List<_Held> _held = [];
  final Set<String> _unknownNoticed = {};
  int _serial = 0;
  bool _disposed = false;

  EventLogController get _log => _ref.read(eventLogProvider.notifier);
  MinecraftLinkController get _link => _ref.read(minecraftLinkProvider.notifier);
  Duration get _timeout => _ref.read(minecraftLinkConfigProvider).ackTimeout;

  /// Помехи, которые сейчас ждут «Второго шанса».
  int get heldCount => _held.length;

  void _onGift(GiftEvent step) {
    if (_disposed) return;
    final record = _ref.read(eventLogProvider).recordFor(step);
    if (record == null) return;
    if (record.isCombo && step.comboActive) return; // серия ещё идёт
    if (!_processed.add(record.id)) return;
    if (_processed.length > 5000) _processed.remove(_processed.first);
    unawaited(_handle(record));
  }

  Future<void> _handle(GiftEvent record) async {
    // Подарок, которого нет в сохранённом каталоге этого эфира.
    final giftId = record.giftId;
    var unknown = false;
    if (record.source == EventSource.tiktok && giftId != null) {
      final catalog = _ref.read(giftCatalogProvider).catalog;
      if (!catalog.isEmpty && catalog.byId(giftId) == null) {
        unknown = true;
        if (_unknownNoticed.add(giftId)) {
          _ref.read(noticeServiceProvider).info(
              'Подарка «${record.giftName}» (ID $giftId) нет в сохранённом каталоге. '
              'Режимы → Паркур → Каталог подарков → «Обновить и проверить каталог».');
        }
      }
    }

    final rules = _ref.read(parkourRulesProvider);
    final rule = rules.modeActive ? rules.ruleFor(record) : null;
    if (rule == null) {
      if (unknown) _log.setAction(record.id, actionState: ActionState.none, unknownGift: true);
      return;
    }
    final link = _ref.read(minecraftLinkProvider);
    final blocker = link.parkourBlocker;
    if (blocker != null) {
      _log.setAction(record.id,
          actionState: ActionState.skipped,
          title: rule.actionTitle,
          result: blocker,
          unknownGift: unknown ? true : null);
      return;
    }

    if (rule.actionId == 'second_chance') {
      _secondChance(record, rule);
      return;
    }
    final secondChance = rules.secondChance;
    if ((rule.action?.hindrance ?? false) && secondChance != null) {
      _hold(record, rule, secondChance);
      return;
    }
    await _execute(record, rule);
  }

  /// Выполнить действие правила для записи (несколько раз — для серии
  /// в режиме «за каждый подарок»).
  Future<void> _execute(GiftEvent record, GiftRule rule) async {
    final times = rule.timesFor(record.count);
    _log.setAction(record.id,
        actionState: ActionState.pending, title: rule.actionTitle, result: 'отправляется в игру');
    final futures = <Future<ModActionResult?>>[];
    for (var i = 0; i < times; i++) {
      futures.add(_send(
        id: times == 1 ? '${record.id}:a' : '${record.id}:a$i',
        action: rule.actionId,
        params: rule.params,
        label: record.giftName,
        viewerName: record.viewerName,
        test: false,
      ));
    }
    final results = await Future.wait(futures);
    if (_disposed) return;
    final okCount = results.where((r) => r != null && r.ok).length;
    _log.setAction(
      record.id,
      actionState: okCount > 0 ? ActionState.done : ActionState.failed,
      title: rule.actionTitle,
      result: combineResults(results),
    );
  }

  Future<ModActionResult?> _send({
    required String id,
    required String action,
    required Map<String, Object?> params,
    required String label,
    required String viewerName,
    required bool test,
  }) {
    final completer = Completer<ModActionResult?>();
    _waiting[id] = completer;
    final sent = _link.sendAction(
      id: id,
      action: action,
      params: params,
      label: label,
      viewerName: viewerName,
      test: test,
    );
    if (!sent) {
      _waiting.remove(id);
      return Future.value(const ModActionResult(id: '', ok: false, result: 'связь с игрой оборвалась'));
    }
    return completer.future.timeout(_timeout, onTimeout: () {
      _waiting.remove(id);
      return null;
    });
  }

  void _onResult(ModActionResult result) {
    final completer = _waiting.remove(result.id);
    if (completer != null && !completer.isCompleted) completer.complete(result);
  }

  // ------------------------------------------------------- второй шанс

  void _hold(GiftEvent record, GiftRule rule, GiftRule secondChance) {
    final seconds = (secondChance.params['seconds'] as num?)?.toInt() ?? 10;
    final countdownId = 'sc-${record.id}';
    _link.sendCountdown(countdownId,
        '«${rule.actionTitle}» от ${record.viewerName} — «${secondChance.giftName}» отменит', seconds);
    _log.setAction(record.id,
        actionState: ActionState.pending,
        title: rule.actionTitle,
        result: 'ждёт $seconds с: «${secondChance.giftName}» может отменить');
    final held = _Held(record, rule, countdownId);
    held.timer = Timer(Duration(seconds: seconds), () {
      if (_disposed || !_held.remove(held)) return;
      unawaited(_execute(record, rule));
    });
    _held.add(held);
  }

  void _secondChance(GiftEvent record, GiftRule rule) {
    if (_held.isEmpty) {
      _log.setAction(record.id,
          actionState: ActionState.done, title: rule.actionTitle, result: 'Нечего отменять — помех нет');
      return;
    }
    final held = _held.removeAt(0);
    held.timer?.cancel();
    final saved = 'Чат спас: «${held.rule.actionTitle}» отменена';
    _link.sendCountdown(held.countdownId, saved, 0);
    _log.setAction(held.record.id,
        actionState: ActionState.skipped,
        title: held.rule.actionTitle,
        result: 'отменено «Вторым шансом» от ${record.viewerName}');
    _log.setAction(record.id,
        actionState: ActionState.done,
        title: rule.actionTitle,
        result: 'Отменил «${held.rule.actionTitle}» от ${held.record.viewerName}');
  }

  // ------------------------------------------------------- проверка

  /// «Проверить в игре»: выполняет действие правила и пишет в историю
  /// запись «Тест · Комната 12 → 11». Работает без эфира.
  Future<ActionOutcome> test(GiftRule rule) async {
    final blocker = _ref.read(minecraftLinkProvider).parkourBlocker;
    if (blocker != null) return ActionOutcome(false, blocker);
    final action = rule.action;
    if (action == null) return const ActionOutcome(false, 'Неизвестное действие');
    final record = GiftEvent(
      id: generateEventId(),
      createdAt: _ref.read(clockProvider)(),
      source: EventSource.test,
      viewerName: 'Тест',
      giftName: rule.giftName,
      count: 1,
      giftId: rule.giftId,
      delivery: DeliveryStatus.sending,
      actionTitle: action.title,
      actionState: ActionState.pending,
      actionResult: 'отправляется в игру',
    );
    _log.add(record);

    if (action.id == 'second_chance') {
      final seconds = (rule.params['seconds'] as num?)?.toInt() ?? 10;
      final countdownId = 'test-sc-${_serial++}';
      final sent = _link.sendCountdown(countdownId, 'Проверка: «Второй шанс от чата»', seconds);
      final text = sent ? 'Обратный отсчёт $seconds с показан в игре' : 'связь с игрой оборвалась';
      _log.setAction(record.id,
          actionState: sent ? ActionState.done : ActionState.failed,
          result: text,
          delivery: sent ? DeliveryStatus.delivered : DeliveryStatus.logOnly);
      return ActionOutcome(sent, sent ? 'Тест · $text' : text);
    }

    final result = await _send(
      id: '${record.id}:test',
      action: action.id,
      params: rule.params,
      label: rule.giftName,
      viewerName: 'Тест',
      test: true,
    );
    if (_disposed) return const ActionOutcome(false, 'Программа закрывается');
    final ok = result != null && result.ok;
    final text = combineResults([result]);
    _log.setAction(record.id,
        actionState: ok ? ActionState.done : ActionState.failed,
        result: text,
        delivery: ok
            ? DeliveryStatus.delivered
            : (result == null ? DeliveryStatus.unconfirmed : DeliveryStatus.logOnly));
    return ActionOutcome(ok, ok ? 'Тест · $text' : text);
  }

  /// Перенос на старт комнаты [room] (подготовка к проверке).
  Future<ActionOutcome> goToRoom(int room) async {
    final blocker = _ref.read(minecraftLinkProvider).parkourBlocker;
    if (blocker != null) return ActionOutcome(false, blocker);
    final result = await _send(
      id: 'goto-${DateTime.now().microsecondsSinceEpoch}-${_serial++}',
      action: 'goto_room',
      params: {'room': room},
      label: '',
      viewerName: '',
      test: true,
    );
    if (result == null) return const ActionOutcome(false, 'Игра не ответила за 5 с');
    return ActionOutcome(result.ok, result.result);
  }

  void dispose() {
    _disposed = true;
    unawaited(_giftSubscription.cancel());
    unawaited(_resultSubscription.cancel());
    for (final held in _held) {
      held.timer?.cancel();
    }
    _held.clear();
    for (final c in _waiting.values) {
      if (!c.isCompleted) c.complete(null);
    }
    _waiting.clear();
  }
}

class _Held {
  _Held(this.record, this.rule, this.countdownId);

  final GiftEvent record;
  final GiftRule rule;
  final String countdownId;
  Timer? timer;
}

/// Один или несколько ответов игры → одна строка для истории.
/// «Комната 12 → 11» ×3 подряд превращается в «Комната 12 → 9».
String combineResults(List<ModActionResult?> results) {
  if (results.isEmpty) return 'нет ответа';
  String one(ModActionResult? r) {
    if (r == null) return 'игра не ответила за 5 с';
    return r.result.isEmpty ? (r.ok ? 'выполнено' : 'не выполнено') : r.result;
  }

  if (results.length == 1) return one(results.single);
  final ok = [for (final r in results) if (r != null && r.ok) r];
  final room = RegExp(r'^(.*?)Комната (\d+) → (\d+)$');
  if (ok.length == results.length) {
    final matches = [for (final r in ok) room.firstMatch(r.result)];
    if (matches.every((m) => m != null)) {
      final first = matches.first!;
      final last = matches.last!;
      return '${first.group(1)}Комната ${first.group(2)} → ${last.group(3)} (×${ok.length})';
    }
    return '${ok.last.result} (×${ok.length})';
  }
  if (ok.isEmpty) return '${one(results.first)} (×${results.length})';
  return '${ok.last.result} — выполнено ${ok.length} из ${results.length}';
}

/// Для подсказки в редакторе: какие действия — помехи.
bool isHindrance(String actionId) => parkourActionById(actionId)?.hindrance ?? false;
