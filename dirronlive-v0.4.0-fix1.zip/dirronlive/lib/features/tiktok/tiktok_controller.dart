import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../settings/settings_controller.dart';
import 'connector_backend.dart';
import 'gift_aggregator.dart';
import 'tiktok_state.dart';

class TikTokConfig {
  const TikTokConfig({
    this.backoff = const [
      Duration(seconds: 2),
      Duration(seconds: 4),
      Duration(seconds: 8),
      Duration(seconds: 16),
      Duration(seconds: 30),
      Duration(seconds: 60),
    ],
    this.finalizeStreakAfter = const Duration(seconds: 15),
  });

  /// Паузы между попытками переподключения после обрыва (растут до 60 с).
  final List<Duration> backoff;

  /// Через сколько тишины незаконченная серия подарков считается завершённой.
  final Duration finalizeStreakAfter;
}

final tiktokConfigProvider =
    Provider<TikTokConfig>((ref) => const TikTokConfig());

final tiktokBackendProvider =
    Provider<TikTokConnectorBackend>((ref) => NodeConnectorBackend());

final tiktokProvider =
    NotifierProvider<TikTokController, TikTokState>(TikTokController.new);

/// Подключение к эфиру TikTok LIVE.
///
/// * «Подключено» — только после того, как коннектор подтвердил вход в эфир
///   указанного аккаунта.
/// * Эфир не идёт → «Эфир не найден» и «Повторить» (без автоповтора).
/// * Ошибка сети или сервиса при подключении → отдельный статус и «Повторить».
/// * Обрыв уже установленного соединения → переподключение с растущей
///   паузой 2, 4, 8, 16, 30, 60 с.
/// * Конец эфира → «Эфир завершён», история уже сохранена.
/// * «Отключиться» → все попытки прекращаются до следующего нажатия.
class TikTokController extends Notifier<TikTokState> {
  TikTokSession? _session;
  StreamSubscription<Map<String, Object?>>? _subscription;
  Timer? _retryTimer;
  int _generation = 0;
  int _attempt = 0;
  bool _wasConnected = false;
  _Outcome? _outcome;
  late TikTokGiftAggregator _aggregator;

  @override
  TikTokState build() {
    final config = ref.watch(tiktokConfigProvider);
    _aggregator = TikTokGiftAggregator(
      publish: (event) => ref.read(eventBusProvider).publish(event),
      clock: ref.read(clockProvider),
      finalizeAfter: config.finalizeStreakAfter,
    );
    ref.onDispose(() {
      _generation++;
      _retryTimer?.cancel();
      unawaited(_subscription?.cancel());
      unawaited(_session?.stop());
      _aggregator.dispose();
    });
    return const TikTokState();
  }

  /// «Подключиться» или «Повторить».
  Future<void> connect() async {
    final nickname = ref.read(settingsProvider).tiktokNickname;
    if (nickname.isEmpty) {
      state = const TikTokState(
        phase: TikTokPhase.off,
        message: 'Сначала укажите ник TikTok.',
      );
      return;
    }
    await _closeSession();
    _retryTimer?.cancel();
    _attempt = 0;
    _wasConnected = false;
    _open(nickname, reconnecting: false);
  }

  /// «Отключиться»: приём прекращается до следующего ручного подключения.
  Future<void> disconnect() async {
    _generation++;
    _retryTimer?.cancel();
    await _closeSession();
    _aggregator.flushAll();
    state = const TikTokState();
  }

  void _open(String nickname, {required bool reconnecting}) {
    final generation = ++_generation;
    _outcome = null;
    state = TikTokState(
      phase: reconnecting ? TikTokPhase.reconnecting : TikTokPhase.connecting,
      uniqueId: nickname,
      attempt: _attempt,
    );
    final apiKey = ref.read(settingsProvider).eulerApiKey;
    final session = ref
        .read(tiktokBackendProvider)
        .start(uniqueId: nickname, apiKey: apiKey.isEmpty ? null : apiKey);
    _session = session;
    _subscription = session.messages.listen(
      (message) {
        if (generation == _generation) _onMessage(nickname, message);
      },
      onDone: () {
        if (generation == _generation) _onSessionEnded(nickname);
      },
    );
  }

  void _onMessage(String nickname, Map<String, Object?> message) {
    switch (message['type']) {
      case 'gift':
        _aggregator.add(message);
      case 'status':
        final text = message['message'] is String
            ? message['message']! as String
            : null;
        switch (message['status']) {
          case 'connected':
            _wasConnected = true;
            _attempt = 0;
            state = TikTokState(
              phase: TikTokPhase.connected,
              uniqueId: nickname,
              message: 'Эфир @$nickname: подарки приходят в Dirronlive.',
            );
          case 'offline':
            _outcome = _Outcome.offline(text);
          case 'ended':
            _outcome = _Outcome.ended(text);
          case 'disconnected':
            _outcome = _Outcome.dropped(text);
          case 'error':
            _outcome = message['kind'] == 'network'
                ? _Outcome.network(text)
                : _Outcome.service(text);
        }
    }
  }

  void _onSessionEnded(String nickname) {
    _session = null;
    _subscription = null;
    _aggregator.flushAll();
    final outcome = _outcome ?? _Outcome.dropped(null);

    switch (outcome.kind) {
      case _Kind.offline:
        state = TikTokState(
          phase: TikTokPhase.offline,
          uniqueId: nickname,
          message: 'Эфир @$nickname сейчас не идёт. Запустите трансляцию '
              'в TikTok LIVE Studio и нажмите «Повторить».',
        );
      case _Kind.ended:
        state = TikTokState(
          phase: TikTokPhase.ended,
          uniqueId: nickname,
          message: 'Эфир завершён, история сохранена.',
        );
      case _Kind.network:
      case _Kind.service:
      case _Kind.dropped:
        if (_wasConnected) {
          _scheduleReconnect(nickname, outcome.message);
        } else {
          state = TikTokState(
            phase: outcome.kind == _Kind.network
                ? TikTokPhase.networkError
                : TikTokPhase.serviceError,
            uniqueId: nickname,
            message: outcome.message ??
                'Коннектор завершился, не подтвердив подключение.',
          );
        }
    }
  }

  void _scheduleReconnect(String nickname, String? reason) {
    final backoff = ref.read(tiktokConfigProvider).backoff;
    final delay = backoff[_attempt < backoff.length ? _attempt : backoff.length - 1];
    _attempt++;
    state = TikTokState(
      phase: TikTokPhase.reconnecting,
      uniqueId: nickname,
      retryIn: delay,
      attempt: _attempt,
      message: 'Связь с эфиром прервалась${reason != null ? ' ($reason)' : ''}. '
          'Попытка $_attempt через ${delay.inSeconds} с.',
    );
    final generation = _generation;
    _retryTimer = Timer(delay, () {
      if (generation != _generation) return;
      _open(nickname, reconnecting: true);
    });
  }

  Future<void> _closeSession() async {
    final session = _session;
    final subscription = _subscription;
    _session = null;
    _subscription = null;
    await subscription?.cancel();
    await session?.stop();
  }
}

enum _Kind { offline, ended, network, service, dropped }

class _Outcome {
  const _Outcome(this.kind, this.message);

  const _Outcome.offline(String? message) : this(_Kind.offline, message);
  const _Outcome.ended(String? message) : this(_Kind.ended, message);
  const _Outcome.network(String? message) : this(_Kind.network, message);
  const _Outcome.service(String? message) : this(_Kind.service, message);
  const _Outcome.dropped(String? message) : this(_Kind.dropped, message);

  final _Kind kind;
  final String? message;
}
