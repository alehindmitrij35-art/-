import 'link_protocol.dart';

/// Фактическое состояние связи с модом Dirronlive Bridge.
enum LinkPhase {
  off('Связь выключена'),
  starting('Запуск связи…'),
  waitingForMod('Ожидание мода'),
  modConnected('Мод подключён • открой одиночный мир'),
  worldReady('Мир готов'),
  error('Ошибка связи');

  const LinkPhase(this.label);

  final String label;
}

class MinecraftLinkState {
  const MinecraftLinkState({
    this.phase = LinkPhase.off,
    this.port,
    this.errorTitle,
    this.errorMessage,
    this.modVersion,
    this.minecraftVersion,
    this.parkourActions = false,
    this.parkour = ParkourInfo.none,
  });

  final LinkPhase phase;

  /// Мод умеет действия паркура (версия 2.0+).
  final bool parkourActions;

  /// Карта в открытом мире: доступна ли, комната игрока.
  final ParkourInfo parkour;

  /// Можно выполнять действия паркура прямо сейчас.
  bool get parkourReady => worldReady && parkourActions && parkour.available;

  /// Почему действия паркура сейчас не выполнить (или `null`, если можно).
  String? get parkourBlocker {
    if (phase == LinkPhase.off) {
      return 'Связь с игрой выключена — включите её в Настройках → Подключения';
    }
    if (!modConnected) return 'Мод Dirronlive Bridge не подключён — запустите Minecraft';
    if (!parkourActions) return 'Мод старой версии — установите Dirronlive Bridge 2.0.0';
    if (!worldReady) return 'Откройте одиночный мир DirronParkour';
    if (!parkour.available) return 'В открытом мире нет карты — откройте мир DirronParkour';
    return null;
  }

  /// Порт, на котором работает (или пытался запуститься) сервер.
  final int? port;

  /// Короткий заголовок ошибки, например «Порт 8765 занят».
  final String? errorTitle;

  /// Понятное объяснение ошибки и что делать.
  final String? errorMessage;

  /// Версии, которые сообщил мод при подключении.
  final String? modVersion;
  final String? minecraftVersion;

  /// Связь включена пользователем (сервер работает или пытается).
  bool get enabled => phase != LinkPhase.off;

  bool get modConnected =>
      phase == LinkPhase.modConnected || phase == LinkPhase.worldReady;

  bool get worldReady => phase == LinkPhase.worldReady;

  /// Текст статуса — одинаковый на экране «Эфир» и в настройках.
  String get label =>
      phase == LinkPhase.error ? (errorTitle ?? phase.label) : phase.label;

  MinecraftLinkState copyWith({
    LinkPhase? phase,
    String? modVersion,
    String? minecraftVersion,
    bool? parkourActions,
    ParkourInfo? parkour,
  }) =>
      MinecraftLinkState(
        phase: phase ?? this.phase,
        port: port,
        errorTitle: errorTitle,
        errorMessage: errorMessage,
        modVersion: modVersion ?? this.modVersion,
        minecraftVersion: minecraftVersion ?? this.minecraftVersion,
        parkourActions: parkourActions ?? this.parkourActions,
        parkour: parkour ?? this.parkour,
      );
}
