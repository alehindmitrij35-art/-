import '../../core/storage/json_store.dart';
import '../../core/storage/storage_exception.dart';
import 'app_settings.dart';

class SettingsLoadResult {
  const SettingsLoadResult(this.settings, this.warnings);

  final AppSettings settings;
  final List<String> warnings;
}

/// Чтение и запись `settings.json`.
class SettingsRepository {
  SettingsRepository(this.store);

  static const fileName = 'settings.json';

  final JsonStore store;

  Future<SettingsLoadResult> load() async {
    Map<String, Object?>? json;
    try {
      json = await store.read(fileName);
    } on StorageException catch (e) {
      return SettingsLoadResult(
          const AppSettings(), ['Настройки не загружены. ${e.message}']);
    } on FormatException {
      final backup = await store.quarantine(fileName);
      final saved =
          backup == null ? '' : ' Копия старого файла сохранена как «$backup».';
      return SettingsLoadResult(const AppSettings(), [
        'Файл настроек повреждён, загружены настройки по умолчанию.$saved',
      ]);
    }
    if (json == null) return const SettingsLoadResult(AppSettings(), []);
    return SettingsLoadResult(AppSettings.fromJson(json), const []);
  }

  Future<void> save(AppSettings settings) =>
      store.write(fileName, settings.toJson());
}
