import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Экраны приложения. Первые четыре — вкладки верхней строки,
/// «Настройки» открываются кнопкой с шестерёнкой справа.
enum AppSection {
  live('Эфир', Icons.sensors_rounded),
  modes('Режимы', Icons.sports_esports_rounded),
  overlays('Оверлеи', Icons.layers_rounded),
  history('История', Icons.history_rounded),
  settings('Настройки', Icons.settings_rounded);

  const AppSection(this.label, this.icon);

  final String label;
  final IconData icon;

  static const tabs = [live, modes, overlays, history];
}

/// Секции экрана настроек, к которым можно перейти напрямую.
enum SettingsSection { tiktok, minecraft }

class SectionController extends Notifier<AppSection> {
  @override
  AppSection build() => AppSection.live;

  void open(AppSection section) => state = section;

  /// Открывает настройки и, если указано, прокручивает к нужной секции.
  void openSettings([SettingsSection? section]) {
    if (section != null) {
      ref.read(settingsFocusProvider.notifier).request(section);
    }
    state = AppSection.settings;
  }
}

final currentSectionProvider =
    NotifierProvider<SectionController, AppSection>(SectionController.new);

/// Запрос «прокрути к секции и выдели её». [serial] растёт с каждым
/// запросом, поэтому повторный переход к той же секции тоже срабатывает.
class SettingsFocus {
  const SettingsFocus(this.section, this.serial);

  final SettingsSection section;
  final int serial;
}

class SettingsFocusController extends Notifier<SettingsFocus?> {
  int _serial = 0;

  @override
  SettingsFocus? build() => null;

  void request(SettingsSection section) =>
      state = SettingsFocus(section, ++_serial);

  void clear() => state = null;
}

final settingsFocusProvider =
    NotifierProvider<SettingsFocusController, SettingsFocus?>(
        SettingsFocusController.new);
